/*
* "Jangan modal nama doang bro!!!"
* (Scriptnya Yanbot
* jangan ubah semuanya kecuali nama bot instagram yt itu ajah yg lain jangan!!!
* hargai pembuat skrip woy!!! DI UBAH AUTO EROR GAN
*/
const XPTN = 'Xryuu'; // JANGAN DI UBAH NNTI EROR
const instagram = 'ramarmdhn.id'; // JANGAN DI UBAH NNTI EROR
const nomer = '085717812568'; // JANGAN DI UBAH NANTI EROR
const aktif = 'SETERAH GW LAH MAU AKTIF KAPAN!'; // DI GANTI AUTO EROR
const groupwa = 'Kgk ada'; // DI GANTI AUTO EROR
const youtube = 'Ga Ada'; // DI GANTI AUTO EROR
//
const qrcode = require("qrcode-terminal");
const moment = require("moment");
const cheerio = require("cheerio");
const get = require('got')
const fs = require("fs");
const dl = require("./lib/downloadImage.js");
const fetch = require('node-fetch');
const urlencode = require("urlencode");
const axios = require("axios");
const imageToBase64 = require('image-to-base64');
const xp = require("./lib/xp.js");
const donate = require("./lib/donate.js");
const info = require("./lib/info.js");
const xp1 = require("./lib/xp1.js");
const xp2 = require("./lib/xp2.js");
const xp3 = require("./lib/xp3.js");
const xp4 = require("./lib/xp4.js");
const xp5 = require("./lib/xp5.js");
const xp6 = require("./lib/xp6.js");
const xp7 = require("./lib/xp7.js");
const xp8 = require("./lib/xp8.js");
const xp9 = require("./lib/xp9.js");
const prefix = "."
const { color, bgcolor } = require("./lib/color.js");
const { getBuffer, fetchJson } = require("./lib/fetcher.js");
const { getGroupAdmins } = require("./lib/functions.js")
const readTextInImage = require('./lib/ocr.js')
const vcard = 'BEGIN:VCARD\n' // metadata of the contact card
            + 'VERSION:3.0\n' 
            + 'FN:Rama\n' // full name
            + 'ORG:Owner Xryuu;\n' // the organization of the contact
            + 'TEL;type=CELL;type=VOICE;waid=6285717812568:+62 857-1781-2568\n' // WhatsApp ID + phone number
            + 'END:VCARD'
//
const
{
   WAConnection,
   MessageType,
   Presence,
   MessageOptions,
   Mimetype,
   WALocationMessage,
   WA_MESSAGE_STUB_TYPES,
   ReconnectMode,
   ProxyAgent,
   waChatKey,
   GroupSettingChange,
} = require("@adiwajshing/baileys");
var jam = moment().format("HH:mm");

function foreach(arr, func)
{
   for (var i in arr)
   {
      func(i, arr[i]);
   }
}
const conn = new WAConnection()
conn.on('qr', qr =>
{
   qrcode.generate(qr,
   {
      small: true
   });
   console.log(`[ ${moment().format("HH:mm:ss")} ] Yanzz Ready scan now!`);
});

conn.on('credentials-updated', () =>
{
   // save credentials whenever updated
   console.log(`credentials updated$`)
   const authInfo = conn.base64EncodedAuthInfo() // get all the auth info we need to restore this session
   fs.writeFileSync('./session.json', JSON.stringify(authInfo, null, '\t')) // save this info to a file
})
fs.existsSync('./session.json') && conn.loadAuthInfo('./session.json')
// uncomment the following line to proxy the connection; some random proxy I got off of: https://proxyscrape.com/free-proxy-list
//conn.connectOptions.agent = ProxyAgent ('http://1.0.180.120:8080')
conn.connect();

conn.on('group-participants-update', async (anu) => {
		try {
			const mdata = await conn.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				try {
					ppimg = await conn.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `Selamat datang di group *${mdata.subject}*\n\nSemoga Nyaman di grup ini🎉🎉`
				let buff = await getBuffer(ppimg)
				conn.sendMessage(mdata.id, buff, MessageType.image, {caption: teks})
			} else if (anu.action == 'remove') {
				try {
					ppimg = await conn.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `Selamat Tinggal👋\n\nSemoga anda Kembali lagi👋`
				let buff = await getBuffer(ppimg)
				conn.sendMessage(mdata.id, buff, MessageType.image, {caption: teks})
			}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})

conn.on('user-presence-update', json => console.log(`[ ${moment().format("HH:mm:ss")} ] => bot by @Yanzz`))
conn.on('message-status-update', json =>
{
   const participant = json.participant ? ' (' + json.participant + ')' : '' // participant exists when the message is from a group
   console.log(`[ ${moment().format("HH:mm:ss")} ] => bot by @Yanzz`)
})

conn.on('message-new', async(m) =>
{
	const from = m.key.remoteJid
   const messageContent = m.message
    const type = Object.keys(m.message)[0]
  body = (type === 'conversation' && m.message.conversation.startsWith(prefix)) ? m.message.conversation : (type == 'imageMessage') && m.message.imageMessage.caption.startsWith(prefix) ? m.message.imageMessage.caption : (type == 'videoMessage') && m.message.videoMessage.caption.startsWith(prefix) ? m.message.videoMessage.caption : (type == 'extendedTextMessage') && m.message.extendedTextMessage.text.startsWith(prefix) ? m.message.extendedTextMessage.text : ''  
  const args = body.trim().split(/ +/).slice(1)
   const text = m.message.conversation
   let id = m.key.remoteJid
   const messageType = Object.keys(messageContent)[0] // message will always contain one key signifying what kind of message
   let imageMessage = m.message.imageMessage;
   console.log(`[ ${moment().format("HH:mm:ss")} ] => Nomor: [ ${id.split("@s.whatsapp.net")[0]} ] => ${text}`);
   // Groups


if (text.includes(".buatgrup"))
   {
var nama = text.split(".buatgrup")[1].split("-nomor")[0];
var nom = text.split("-nomor")[1];
var numArray = nom.split(",");
for ( var i = 0; i < numArray.length; i++ ) {
    numArray[i] = numArray[i] +"@s.whatsapp.net";
}
var str = numArray.join("");
console.log(str)
const group = await conn.groupCreate (nama, str)
console.log ("created group with id: " + group.gid)
conn.sendMessage(group.gid, "hello everyone", MessageType.extendedText) // say hello to everyone on the group

}
const botNumber = conn.user.jid
			const ownerNumber = ["6285717812568@s.whatsapp.net"] // replace this with your number
			const isGroup = from.endsWith('@g.us')
			const sender = isGroup ? m.participant : m.key.remoteJid
			const groupMetadata = isGroup ? await conn.groupMetadata(from) : ''
			const groupName = isGroup ? groupMetadata.subject : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
			const isBotGroupAdmins = groupAdmins.includes("6285717812568@s.whatsapp.net") || false
			const isGroupAdmins = groupAdmins.includes(sender) || false
const isOwner = ownerNumber.includes(sender)


const mentions = (teks, memberr, id) => {
				(id == null || id == undefined || id == false) ? conn.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : conn.sendMessage(from, teks.trim(), extendedText, {quoted: m, contextInfo: {"mentionedJid": memberr}})
			}

// FF XP-TN
if(text.includes(".cek")){
var num = text.replace(/.cek/ , "")
var idn = num.replace("0","+62");

console.log(id);
const gg = idn+'@s.whatsapp.net'

const exists = await conn.isOnWhatsApp (gg)
console.log(exists);
conn.sendMessage(id ,`${gg} ${exists ? " exists " : " does not exist"} on WhatsApp`, MessageType.text)
}
//Chat XP-TN
else if (text == 'asalamualaikum'){
conn.sendMessage(id, '*وَعَلَيْكُمُ السَّلاَمُ*        Waalaikumsalam' ,MessageType.text);
}
else if (text == 'Assalamualaikum'){
conn.sendMessage(id, '*وَعَلَيْكُمُ السَّلاَمُ*        Waalaikumsalam' ,MessageType.text);
}
else if (text == 'halo'){
conn.sendMessage(id, 'Halo juga' ,MessageType.text);
}
else if (text == 'hai'){
conn.sendMessage(id, 'Hai juga' ,MessageType.text);
}
else if (text == 'p'){
conn.sendMessage(id, 'papepape, Ucapkan Salam Dlu' ,MessageType.text);
}
else if (text == 'P'){
conn.sendMessage(id, 'Papepape, Ucapkan Salam Dlu' ,MessageType.text);
}
else if (text == '.menu1'){
conn.sendMessage(id, ' *Menampilkan Fitur Menu1!!!* ' ,MessageType.text);
}
else if (text == '.menu2'){
conn.sendMessage(id, ' *Menampilkan Fitur Menu2!!!* ' ,MessageType.text);
}
else if (text == '.menu3'){
conn.sendMessage(id, ' *Menampilkan Fitur Menu3!!!* ' ,MessageType.text);
}
else if (text == '.menu4'){
conn.sendMessage(id, ' *Menampilkan Fitur Menu4!!!* ' ,MessageType.text);
}
else if (text == '.menu5'){
conn.sendMessage(id, ' *Menampilkan Fitur Menu5!!!* ' ,MessageType.text);
}
else if (text == '.menu6'){
conn.sendMessage(id, ' *Menampilkan Fitur Menu6!!!* ' ,MessageType.text);
}
else if (text == '.menu7'){
conn.sendMessage(id, ' *Menampilkan Fitur Menu7!!!* ' ,MessageType.text);
}
else if (text == '.menu8'){
conn.sendMessage(id, ' *Menampilkan Fitur Menu8!!!* ' ,MessageType.text);
}
else if (text == '.menu9'){
conn.sendMessage(id, ' *Menampilkan Fitur Menu9!!!* ' ,MessageType.text);
}
else if (text == 'Siang'){
conn.sendMessage(id, ' _Siang juga, Pesan ini Terjawab Otomatis:)_ ' ,MessageType.text);
}
else if (text == 'Sore'){
conn.sendMessage(id, ' _Sore juga, Pesan ini Terjawab Otomatis:)_ ' ,MessageType.text);
}
else if (text == 'Malam'){
conn.sendMessage(id, ' _Malam juga, Pesan ini Terjawab Otomatis:)_ ' ,MessageType.text);
}
else if (text == 'Selamat malam'){
conn.sendMessage(id, 'Selamat malam juga, Pesan ini Terjawab Otomatis:)' ,MessageType.text);
}
else if (text == 'Selamat pagi'){
conn.sendMessage(id, 'Selamat pagi juga, Pesan ini Terjawab Otomatis:)' ,MessageType.text);
}
else if (text == 'Selamat siang'){
conn.sendMessage(id, 'Selamat siang juga, Pesan ini Terjawab Otomatis:)' ,MessageType.text);
}
else if (text == 'Selamat sore'){
conn.sendMessage(id, 'Selamat sore juga, Pesan ini Terjawab Otomatis:)_ ' ,MessageType.text);
}
else if (text == 'thx'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text);
}
else if (text == 'Thx'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text);
}
else if (text == 'mksih'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text);
}
else if (text == 'Mksih'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text);
}
else if (text == 'makasi'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text);
}
else if (text == 'Makasi'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text);
}
else if (text == 'makasih'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text);
}
else if (text == 'Makasih'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text);
}
else if (text == 'thank'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text);
}
else if (text == 'Thank'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text);
}
else if (text == 'thanks'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text);
}
else if (text == 'Thanks'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text);
}
else if (text == '.intro'){
conn.sendMessage(id, '📌HALO MEMBER YANG BARU MASUK intro yak kak :Sebutin Nama, Umur, Askot, Status?;v' ,MessageType.text);
}
else if (text == '.instaowner'){
conn.sendMessage(id, 'Mutualan Yok https://instagram.com/ramarmdhn.id' ,MessageType.text);
}
// Fitur

if (text.includes('.nulis')){
  var teks = text.replace(/.nulis /, '')
    axios.get('https://bangandre.herokuapp.com/nulis?teks='+teks)
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[WAIT]Sedang Menulis Pesanmu🔎', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}
if (text.includes('.kpop')){
  var aris = text.replace(/ /, '')
    axios.get(',https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/random/kpop/')
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[ WAIT ] Sedang di proses⏳ silahkan tunggu sebentar', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}
if(text.includes(".nhentai")){
var num = text.replace(/!help/ , "")
var idn = num.replace("0","+62");

console.log(id);
const gg = idn+''

const exists = await conn.isOnWhatsApp (gg)
console.log(exists);
conn.sendMessage(id ,`╔ ═〘 *♥️NHENTAI ♥* 〙╗
CODE NUKLIR 
192704 NTR bathroom
313777 NTR senpai
314237 incets
267352 anak bngsd
221271 jutek
298444 Loli 
/g/181556/ - Fudeoro Sisters
/g/152456/ - Mou Teitoku No Soba 
/g/167936/ - Inma Mo Mikata
/g/139048/ - shojo soushitsu
/g/185592/ - Gensoukyou Rakuenka Keikaku 11
/g/191427/ - Kousei Iinkai
/g/175015/ - Sister Breeder
/g/142825/ - A Certain Village
/g/182290/ - A hero taken prisoner
/g/192845/ - Toaru Natsu
/g/192849/ - Toaru Fuyu
/g/183099/ - Adolescent calculation
/g/192143/ - Blonde no koigokoro
/g/142825/ - Toaru mura no Fudeoroshi Jijou
/g/153856/ - Tenryuu Onee-chan fo naisho no Yasen Enshuu!!
/g/158404/ - Kusogaki
/g/136026/ - Megaflower x flower
/g/188918/ Kodomo no Ecchi
/g/193876/ - Razoku no Yoru
/g/193984/ - Houkago Rendezvous
/g/76119/ - Broadcast Girlfriend
/g/192874/ - Koyomi Fechi
/g/107180/ - Harem Bukai no Boku
/g/110900/ - Kiniro
/g/135193/ - It's my win!
/g/161488/ - Shota Teitoku to Nyuukyo Time
/g/65433/ - Jirettai no Yo!
/g/182327/ - Sakeno Seiton
/g/78651/ - Harem Time
/g/190230/ - Boku no Bimama
/g/191880/ - Sanae Hamaru
/g/180600/ - Sakaki-san Satisfaction
/g/105465/ - Sakaki-san Franchise
/g/173023/ - Tiny Evil
/g/191049/ - Kono Suba 1
/g/191851/ - Kono Suba 2
/g/167112/ - i'll be your cat
/g/177754/ - Sloppy Sister
/g/187016/ - Nanyou no Vacances Sakusen
/g/165961/ - Love-ridden
/g/165962/ - Pandemonium
/g/97879/ - Natsuyasumi
/g/74500/ - Nee-chan no yobanaide
/g/133435/ - Spirited Girl
/g/152075/ - Trick And Treat
/g/174888/ - Razoku No Yoru
/g/93354/ - Melty Play
/g/74076/ - BAD COMMUNICATION
/g/122948/ - PLAY BACK
/g/104346/ - Funky Glamourous
/g/91773/ - Good Times!!
/g/78226/ - Practice Game
/g/76482/ - JOINT
/g/68508/ - Kimi ga iru nara
/g/61224/ - Way back to the future
/g/60473/ - Hoshi ni negai o
/g/58469/ - Splash
/g/56295/ - Heat Island
/g/53905/ - I Beg You
/g/42383/ - Rumors
/g/187611/ - My Dear Maid
/g/190846/ - Tsukimi Dango
/g/158050/ - Muchimuchi
/g/83269/ - Only a taste for Onee-Chan
/g/146042/ - Bismarck wa Shounen Teitoku kara Seifuku
/g/178941/ - Kodomo-Sensei
/g/100401/ - Sister paradise
�229144 253687 238577 236509
�227675 229085 233245 266177
254351 265855 239842 219847
239749 230566 253104 230185
251974 253091 251489 238030
260614 245023 232887 233547
262158 262870 239312 255129
244530 246963 256050 215459
243725 233770 250704 261819
261830 215658 256404 260028
261789 241254 268580 262407
262252 201814 250193 236036
262889 243933 245697 239750
128983 95364 223815 225080
110332 225767 97247 231139
266116 217037 160657 182439
205089 176495 199121 199425
184068 186615 224644 129479
251524 153374 146499 258212
163532 255244 269825 235914
247103 138365 124624 219718
168941 265918 205995 191390
�225496 259137 231681 161688
�199613 259260 260433 235532 
�88323 272117 170213 256613
�258382 224942

/g/181556/ - Fudeoro Sisters
/g/152456/ - Mou Teitoku No Soba 
/g/167936/ - Inma Mo Mikata
/g/139048/ - shojo soushitsu
/g/185592/ - Gensoukyou Rakuenka Keikaku 11
/g/191427/ - Kousei Iinkai
/g/175015/ - Sister Breeder
/g/142825/ - A Certain Village
/g/182290/ - A hero taken prisoner
/g/192845/ - Toaru Natsu
/g/192849/ - Toaru Fuyu
/g/183099/ - Adolescent calculation
/g/192143/ - Blonde no koigokoro
/g/142825/ - Toaru mura no Fudeoroshi Jijou
/g/153856/ - Tenryuu Onee-chan fo naisho no Yasen Enshuu!!
/g/158404/ - Kusogaki
/g/136026/ - Megaflower x flower
/g/188918/ Kodomo no Ecchi
/g/193876/ - Razoku no Yoru
/g/193984/ - Houkago Rendezvous
/g/76119/ - Broadcast Girlfriend
/g/192874/ - Koyomi Fechi
/g/107180/ - Harem Bukai no Boku
/g/110900/ - Kiniro
/g/135193/ - It's my win!
/g/161488/ - Shota Teitoku to Nyuukyo Time
/g/65433/ - Jirettai no Yo!
/g/182327/ - Sakeno Seiton
/g/78651/ - Harem Time
/g/190230/ - Boku no Bimama
/g/191880/ - Sanae Hamaru
/g/180600/ - Sakaki-san Satisfaction
/g/105465/ - Sakaki-san Franchise
/g/173023/ - Tiny Evil
/g/191049/ - Kono Suba 1
/g/191851/ - Kono Suba 2
/g/167112/ - i'll be your cat
/g/177754/ - Sloppy Sister
/g/187016/ - Nanyou no Vacances Sakusen
/g/165961/ - Love-ridden
/g/165962/ - Pandemonium
/g/97879/ - Natsuyasumi
/g/74500/ - Nee-chan no yobanaide
/g/133435/ - Spirited Girl
/g/152075/ - Trick And Treat
/g/174888/ - Razoku No Yoru
/g/93354/ - Melty Play
/g/74076/ - BAD COMMUNICATION
/g/122948/ - PLAY BACK
/g/104346/ - Funky Glamourous
/g/91773/ - Good Times!!
/g/78226/ - Practice Game
/g/76482/ - JOINT
/g/68508/ - Kimi ga iru nara
/g/61224/ - Way back to the future
/g/60473/ - Hoshi ni negai o
/g/58469/ - Splash
/g/56295/ - Heat Island
/g/53905/ - I Beg You
/g/42383/ - Rumors
/g/187611/ - My Dear Maid
/g/190846/ - Tsukimi Dango
/g/158050/ - Muchimuchi
/g/83269/ - Only a taste for Onee-Chan
/g/146042/ - Bismarck wa Shounen Teitoku kara Seifuku
/g/178941/ - Kodomo-Sensei
/g/100401/ - Sister paradise
/g/35240/ - Eiken Lovers
/g/77415/ - Koinaka
/g/190900/ - Grazero Fantasy
/g/161819/ - Night Of Incest
/g/151132/ - Pet Na Ane No Shitsukekata
/g/147585/ - Anetsun Summer!
/g/136908/ - Man x Koi
/g/112907/ - Imouto x Swimming!
/g/125392/ - Joubutsu!
/g/174463/ - Hotizuma Miyuki-San
/g/159290/ - Mister Mistake
/g/137953/ - Hotondo Byouki
/g/114053/ - Unknown Title 
/g/78818/ - Furofuro!
/g/15055/ - Demodori Mama
/g/39876/ - Cherry Break
/g/191427/ - Doutei Danshi Kousei Iinkai
/g/192695/ - Costte Asobo.
/g/192330/ - Level 1
/g/191320/ - Kimi Ni Nara Dekiru
/g/164434/ - MIDNIGHT PRINCESS
/g/76813/ - Superior Cake
/g/148669/ - Ohime-sama Gokko
/g/144806/ - Youkai Watching
/g/163698/ - Escalation
/g/158559/ - Jiyuu de Kimama na Ore no Imouto
/g/182210/ - Hatsujou Days
/g/131428/ - Having Fun With The One That I Love
/g/112853/ - Boku to Oneesan no Naisho
/g/178594/ - Imouto no Oppai ga Marudashi Datta Hanashi 1
/g/195665/ - Imouto no Oppai ga Marudashi Datta Hanashi 2
/g/195092/ - Imouto no Oppai ga Marudashi Datta Hanashi 3
/g/195093/ - Imouto no Oppai ga Marudashi Datta Hanashi 4

�229144 253687 238577 236509
�227675 229085 233245 266177
254351 265855 239842 219847
239749 230566 253104 230185
251974 253091 251489 238030
260614 245023 232887 233547
262158 262870 239312 255129
244530 246963 256050 215459
243725 233770 250704 261819
261830 215658 256404 260028
261789 241254 268580 262407
262252 201814 250193 236036
262889 243933 245697 239750
128983 95364 223815 225080
110332 225767 97247 231139
266116 217037 160657 182439
205089 176495 199121 199425
184068 186615 224644 129479
251524 153374 146499 258212
163532 255244 269825 235914
247103 138365 124624 219718
168941 265918 205995 191390
�225496 259137 231681 161688
�199613 259260 260433 235532
�88323 272117 170213 256613
�258382 224942

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
● Milf ●
165310,177978,211759,212643,229540, 250029,211519,256097,163478, 91505, 79280, 260629,128051,121972,261633,172044,19055,208323,149942,161236, 177150,233766,97949,230107 ,175822, 213545,232837,179166,138603,130183, 173543,234642,268015,228293,268893, 239536, yg suka mamah
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
● Random ●
257892 226942 236297 216039 221711 245304 166174 175220

107817 MASTURBATION MAID
181008 MATING ONI DAUGTHER
183714 MATING ONI MOTHER
230041 MICRO BIKINI LOLI
114883 OREIMO COLORED
146595 YOU DAMN COWARD
197074 RECO SEKU
245855 ONI REM BOOK
51332 JURI GAME
251067 LOLI ONSEN
127894 AIKATSU SUMMER IDOL
118282 YUKINYA! 
94579 ANO NATSU OKINAWA
123554 TEISOU KANNEN ZERO
206250 NAKED SWIMMING CLASS
258972 NAKED SWIMMING CLASS 2
75165 GIRLS IN THE FRAME
85289 CAST AOI
217410 SEIKATSU SHUUKAN
102839 THE LIGHT OF TSUKIMI MANOR 
123450 THE SEX LIFE OF TACHIBANAS
228433 SAEKANO MEGURI
254730 NAKED RANDOSERU MEET-UP
200855 I SAVED AN ELF LOLI
225792 I SAVED AN ELF LOLI 2
194036 PLAYING SHOP
79081 AZUSA ATTACK 1
79181 AZUSA ATTACK 2
107668 AZUSA ATTACK 3
245000 AZUSA ATTACK 4
234741 TANAKA'S SISTER'S SECRET 
256161 SCHOOLGIRLS' BREAST EXPOSED
254838 GUILD GIRL AND GOBLIN SLAYER
258741 ARCHWIZARD EXPLOSION MAGIC
175399 GIVING SOMETHING TO MEGUMIN
214111 MC GAKUEN
127981 MY NEIGHBOR RINA
73758 KURONEKO YUKATA
62886 KURONEKO COSPLAY
110648 BATTLE OF KURONEKO
256857 GIRLFRIEND, BOYFRIEND, MANAGER 
262664 GIRLFRIEND, BOYFRIEND, MANAGER 2
178983 WE FUCKED LIKE RABBITS
264018 YET INNOCENT MAIDEN
168120 SHORT PANTS AND OTHERS
112373 POPULARITY OF SHORT PANTS
201031 TRAUMEREI
150933 HELLO LOLITA! 
233766 HELPFUL MOTHER
207964 BROTHER SISTER MAKE PROPER LOVE
142825 A CERTAIN VILLAGE CUSTOM
182290 HERO, DEMON QUEEN AND HER ELF
225904 BOOBS AS REWARD
252784 SISTER IN THE MIXED HOT SPRINGS
180364 MY NEIGHBOR IS A SUCCUBUS
252783 AFTER SCHOOL SEX TREATMENT
110955 AIR HEAD DELIVERY
194163 LOVE FROM THE ASS
114737 DICK CONQUEST
240667 LET'S KISS WITH THE LOWER MOUTH
267270 I'M NO VIRGIN!
266965 HIFUMI FOUND HER SUGAR DADDY
274917 MURAMATA'S SECRET
234363 LOLI SUCCUBUS' MEALTIME
264920 COACH CHIKA
123141 READY STEADY GO
128980 READY STEADY GO 2
262816 LEAVE IT TO ONEE-CHAN
122064 DANGEROUS? SISTERS
266942 NITTA-SAN AT HOME
239369 NITTA-SAN AT SCHOOL
262395 PUBERTY STUDY SESSION 
137065 MEATY MATE
197482 PETITX
158464 JC MANUAL
237482 JUST KEEP WATCHING
191489 INFILTRATION! BOYISH
249257 INFILTRATION! BOYISH 2
260807 INFILTRATION! BOYISH 3
253687 ANOTHER WORLD LEWD MAGIC
266402 ANOTHER WORLD LEWD MAGIC 2
249660 CHILDREN LEARNS SEX
136671 PEACHY BUTT GIRLS
267816 IKUMONOGAKARI DELUXE BAN
220380 VARIOUS LOLI
150436 INDEPENDENT RESEARCH 
224786 ERO PIPPI
42298 TSUNDERO
178931 BECAUSE IT'S YOU SHORTY
181184 KANOMAMA
167586 KID SLUTS
255662 ANE NARU MONO
235594 INAKAX
111258 KIGURUMIX
176994 WHERE DID YOU GO THIS SUMMER 
60473 GRANT MY WISH
268236 AYUNE-CHAN ANAL ECCHI
265725 NPC RAPE MOD
265399 PETIT LOVE COLORED HOLE
238949 MY LITTLE STAR
172018 ANYTHING AFTER THE PHOTOSHOOT 
204352 NATSU NO KISETSU
150749 KONDO NO RACE
237293 BODY COMPLEX
47624 SIBLING LUST
268807 TAIFUU IKKA
188918 SEX MANUAL FOR KIDS
74396 KYARAME-LOLI 
178874 PUCHI BITCH
244977 INDECENT WIN WITH A COLLEGE GIRL
211765 COULD HAPPEN DURING AFTERSCHOOL
95185 MY LITTLE SISTER GOT A BOYFRIEND 
268015 ZENIN SHIKKAKU
82055 HOKENIIN SURVIVAL
269533 OUR GRADUATION CEREMONY
110896 CUTE LITTLE SISTER
265395 ENJOYING SUMMER 
233187 TAKAO-SAN'S SERVICE
240960 WE'RE ON AIR SO BE QUIET
236926 LOOK AT ME AS A GIRL
267470 HANGING OUT WITH MY BIG BROTHER
125987 THE PLACE WHERE I MET UMI
263516 GOBLIN SLAYER HAREM
136393 SUZUKA-SAMA'S SERVANT
227910 SIBLING SEX
114057 CHIKANYA-SAN 
154284 SHOGO BEAT
177489 HINATA NTRISM
192215 DEKOBOKO LOVE SISTER
86129 PORNO SWITCH 
265660 IINARI ACME
168285 BAT?! WOMAN
211648 THE ARCHDEMON IN LOVE 
176656 JOGGING LOLI
272117 MY CHEEKY SISTER BECOMES A DOG
271494 DICK SELLING MAN
258390 SEX FRIEND MOMMA
271890 ERROR OF CALL
259827 STRAY CAT GIRL
258241 IDEAL GIRLFRIEND 
126937 I'LL PRACTICE WITH MY SISTER
209814 TAKUMI-AKI RIN
196016 THE KIDNAPPER SHE LOVED
253618 THEY WANT TO ENTER MEN'S BATH
156795 LITTLE SISTER IS THE CUTEST
274290 KOMI-SAN STRANGE IDEA ABOUT SEX
228626 BOYISH GIRLFRIEND
249743 BOYISH GIRLFRIEND 2
272029 BOYISH GIRLFRIEND 3
272975 BOYISH GIRLFRIEND 4
234638 FATE COLORED
199533 OMNIVOROUS HERO
220794 HORNY ANDROIDS
274555 SEX WITH MY CHILDHOOD FRIEND
255678 OCEAN PARADISE
94966 SLIMY BELLOWS
246032 BULLY ME NAGATORO-SAN
256100 THIGH SITUATION
272050 YES TO FLAT CHEST
107353 FRIENZIED TRIPLE
139512 ZOMBIE ERO MANGA
227463 LEVEL 1
203511 RIN'S FALL
207726 GUP HSIDE
260527 ENKOU OJISAN
151941 TRIP DUNGEON
246011 NADE CAMP
258654 HORE TOKIDOKI NUKUMORI
122876 JOB OF A COMMITTEE MEMBER
151256 AMAGI MITEIAN
143349 THUNDER GIRL
238873 SCARLET LUST
173896 RUN GIRL RUN
230275 DEMON LOLI FATE
185217 R.E.I.N
154089 245473 257867 239159 239820 4039 254903 1241 124919 63207 100287 222359 154951 28061 67226 28359 125838 42751 86322 93125 260151 49189 28018 242166 98771 259880 38827 81971 164946 252067 118261 141699 103454 102317 78392 52038 92888 146170 140437 76281 56047 257486 121132 12709 187334 232255 232255 76273 131406 173289 55907 135440 178640 48680 247587 70178 39487 84663 213693 121009 249935 189774 186729 117046 164345 202735 162075 51212 4295 218436 145303 205437 223438 146105 23933 38886 73936 237026 205427 104036 248318 146843 3743 121136 114634 168501 116602 229151 45689 237889 117435 242163 142422 27027 25940 61748 153284 236393 230775 16835 254152 132572 132572 205856 87639 175124 267949 104619 1158 144726 97984 114619 247970 248800 95558 37030 43621 238547 236283 136018 163398 92050 96999 137191 74648 70475 247229 168175 234921 88347 117957 35962 136088 98879 259201 87152 181235 42912 201358 114790 38691 236481 200631 257164 267987 147751 77146 183191 159852 224514 32380 208152 123768 199489 62529 122161 90791 73206 152299 90641 105671 268803 72737 118565 128142 182543 259739 162377 92414 108371 200629 158150 72345 9138 114118 5944 78100 222995 138839 8189 165888 102016 196044 208863 134460 86152 15752 142440 36590 71710 248618 186139 63675 10002 210268 241043 170027 220041 193448 213624 42460 241296 93008 72953 60624 35634 43525 183414 84531 80199 221306 225945 9037 56185 13176 166411 185184 11350 78525 180027 164869 43742 84686 166817 15543 208626 34270 116759 212084 156750 243973 3341 85848 71207 147591 253076 28 87114 204403 252971 173645 162780 25809 11484 222071 
152809 106661 102222 154215 246366
17830 118581 68777 8861 91321 84274 232846 247295 113306 159042 121173 130 13042 13401 8501 115 3528 416 17214 11310 18147 18222 21560 10247 11518 23677 13605 3494 14936 98092 5905 11311 10392 10371 0302 21290 5161 39695 23571 17504 11269 18276 18101 0317 0228 17694 4473 22224 22200 19452 21589 67893 5569 13918 8958 12137 1333 4725 4458 5905 17166 13851 4458 17149 14471 6706 13850 12224 0929 14991 7382 15857 67893 14218 36477 5870 17553 67803 5870 5454 16102 15217 22801 17138 21001 17388 7446 23638 18222 6719 14331 15021 23845 3168 23552 22096 21604 4797 9497 22464 20855 4377 23610 18140 22260 5905 13347 20420 39689 13732 20667 6929 5275 18507 52262 1340 22049 13339 11265 22295 10439 14814 4178 6992 8784 7632 7357 6936 52262 11267 21100 21272 9340 9559 23464 15874 18502 18500 15857 2188 5376 7381 98092 16127 13486 9350 9220 76036 14219 5144 2831 17920 11347 17142 11264 7667 7762 15099 9110 10482 97556 3569 3670 243896 226387 82506 134764 220958 188337 142825 137838 247696 134442 191227 243896 250431 150180 68609 118174 194036 251338 248406 240302 128602 140791 197729 197782 236277 226181 236713 197353 205995 191390 117424 24909 20558 88336 235157 236910 239393 242683 250684 211759 250575 196880 194265 248717 225022 250287 139721 250035 148726 235905 156153 248717 100531 213586 242517 218308 242478 206905 213211 242357 191773 162662 209519 195287 223960 232398 150416 237635 228032 240545 238549 91568 243104 197422 228080 237326 222855 227463 241970 233736 110903 192317 235537 230439 240296 241467 222410 196557 115500 232110 97067 233773 234546 243304 246796 246403 185406 153841 147103 240560 147184 203402 155366 114750 245493 248487 215243 135032 233370 244691 76666 249743 252782 265803 211869 241777 247129 147001 245258 166001 149245 123442 258741 256917 257125 257123 257136 257085 128936 245413 193031 256896 222957 225553 224600 177301 144965 229822 237468 242739 191773 162662 209519 195287 223960 232398 242580 242276 241880 190332 228922 74396 218511 139512 241657 241654 241665 246622 239691 239944 226738 228952 237635 240354 201129 226503 14920 158558 240072 128502 233379 147184 147395 160011 147308 157642 179800 179801 240560 143349 206734 63386 230184 236525 215971 207718 238577 150134 242169 150933 105582 243252 245682 200424 112940 118282 173023 336104 111986 190050 198432 241677 243773 215078 180029 177013 158902 191227 196348 194965 31064 193941 246525 211648 220210 247104 240757 110647 193770 246403 183590 104753 247576 218810 114750 151165 245074 165950 247888 212521 228922 248624 248623 248622 248619 248618 248615 248613 248612 224644 248393 248394 248397 129911 90423 248717 240296 171461 249249 242460226068 193770 188342 249646 249556 249405 249588 249586 249577 249551 249543 249544 166427 242987 249569 206295 249564 168574 249554 249497 72987 181008 249805 249947 51790 207965 246171 136779 193568 232393 200834 222274 249272 250605 72987 179267 220629 142286 251746 251701 242925 250315 185333 242503 251735 199812 251717 249483 251675 213444 168716 106205 249650 251687 158050 251687 158050 251718 246999 243826 134441 244308 201814 191654 217827 172029 173911 160417 251742 251737 228984 228932 181775 204224 191773 172029 177478
167466 165684 254048 175015 174016 142825 129128 171417 129128 95809 239567 247021 46579 123580 171417 173543 197422 187835 217832 206573 169546 193107 190805 220309 211112 132768 97945 164783 206446 251608 90182 256018 138470 110826 175494 134764 145647 212562 179166 214784 176977 191434 191434 239536 236342 227702 204425 205079 85333 254935 232837 232385 232341 254087 50535 235202 94159 52365 255034 153045 159457 173235 96270 196020 191774 230332 95298 89514 73649 203027 217404 65573 255457 199874 233133 205367 233693 50046 234191 209455 206366 253799 39249 172197 243552 223998221050 217456 225019 234165 258245 247696 258212 258465 86493 258133 244327 260640 261171 244996 202634 165950 220967 120977 204746 142850 99439 232439 246032 200948 265804 25913 262861 196077
155489 257528 267270 177044 267502 184840
144714 228575 268002 267980 227439 267980
268015 89502 228575 220893 160609 261107 110747 235532 248196 228948 259361 235032 139512 257528 260369 261650 234174 116174 239732 213835 146913 216227 182290 117013 259600 139512 258479 173101 235532 258488 264551 263661 242668 154884 150096 265842 259137 781573 234734 244436 265841 265837 255337 110955 265842 266301 928040 122557 135420 209519 265756 136489 242517 266965 134035 266613 183469 244996 255662 267352 208797 267270 267043 213560 261868 267352 186938 267369 263516 266942 111292 233513 262069 172807 263960 184840 266495 252548 267617 193770 262668 225918 147759 154290 240108 240110 208486 240113 242586 257960 109168 109395 109519 112206 231215 246186 267980 259491 265933 196016 235032 228948 131056 121927 134861 195791 116300 268362 152889
167466 165684 254048 175015 174016 142825 129128 171417 129128 95809 239567 247021 46579 123580 171417 173543 197422 187835 217832 206573 169546 193107 190805 220309 211112 132768 97945 164783 206446 251608 90182 256018 138470 110826 175494 134764 145647 212562 179166 214784 176977 191434 191434 239536 236342 227702 204425 205079 85333 254935 232837 232385 232341 254087 50535 235202 94159 52365 255034 153045 159457 173235 96270 196020 191774 230332 95298 89514 73649 203027 217404 65573 255457 199874 233133 205367 233693 50046 234191 209455 206366 253799 39249 172197 243552 223998221050 217456 225019 234165 258245 247696 258212 258465 86493 258133 244327 260640 261171 244996 202634 165950 220967 120977 204746 142850 99439 232439 246032 200948 265804 25913 262861 196077
155489 257528 267270 177044 267502 184840
144714 228575 268002 267980 227439 267980
268015 89502 228575 220893 160609 261107 110747 235532 248196 228948 259361 235032 139512 257528 260369 261650 234174 116174 239732 213835 146913 216227 182290 117013 259600 139512 258479 173101 235532 258488 264551 263661 242668 154884 150096 265842 259137 781573 234734 244436 265841 265837 255337 110955 265842 266301 928040 122557 135420 209519 265756 136489 242517 266965 134035 266613 183469 244996 255662 267352 208797 267270 267043 213560 261868 267352 186938 267369 263516 266942 111292 233513 262069 172807 263960 184840 266495 252548 267617 193770 262668 225918 147759 154290 240108 240110 208486 240113 242586 257960 109168 109395 109519 112206 231215 246186 267980 259491 265933 196016 235032 228948 131056 121927 134861 195791 116300 268362 152889 134500 268338 220735 192060 113276 265526 264824 126784 191851 103366 229144 158651 257484 248696 265804 206387 158123 136188 235928 194941 208797 241819 239732 215376 220212 165957 266906

${gg} ${exists ? " exists " : "*[ Xryuu-BOT ]* 💕"}`, MessageType.text)
}
if(text.includes(".bhsjepang")){
var num = text.replace(/!help/ , "")
var idn = num.replace("0","+62");

console.log(id);
const gg = idn+''

const exists = await conn.isOnWhatsApp (gg)
console.log(exists);
conn.sendMessage(id ,`╔ ═〘 *♥  ️Xryuu-BOT♥  ️* 〙╗

*[ Bahasa Jepang yang paling umum ]*

• Senpai = Senior 
• Kouhai = Junior 
• Hidoi = Jahat 
• Dousta? = Kenapa?, Ada apa? 
• Nani!! = Apa!! 
• Zutto = Kalau saja, Selalu 
• Kirei = Indah 
• Kawaii = Cantik, Imut 
• Yaksoku = Janji 
• Kedo/Demo = Tapi 
• Warui/Gomen = Maaf 
• Sumimasen = Permisi, maaf 
• Omedetou, ne = selamat ya 
• Dame = Jangan, Tidak 
• Sugoi! = Hebat, Keren 
• Daijoubu desu = Saya tidak apa apa / Saya baik baik saja 
• Hanabi = Kembang api 
• Tadaima = Aku pulang 
• Okaerinasai = Selamat pulang 
• Ja, mata/ Mata ne = Sampai jumpa 
• Ittekimasu = Aku berangkat 
•Itterasshai = Hati hati di jalan 
• Ohayou gozaimasu= Selamat Pagi 
• Konnichiwa (ha) = Selamat Siang 
• Konbanwa (ha) = Selamat Malam 
• Oyasuminasai = Selamat tidur 
• Moshi-moshi = Halo (di ucapkan ketika berada dalam sosmed) 
• Zannen desu = Sayang sekali 
• Irasshaimase = Selamat datang 
• Onegai = Tolong 
• Yoroshiku Onegaishimasu = Mohon bimbingannya/bantuannya 
• Doumo/Arigatou = Terima Kasih 
• Iya = Hai 
• Iie = Tidak 
• Ittadakimasu = Selamat makan 
• Nandemonai = Bukan apa apa 
• Nanda korewa? = Apa ini? 
• Dare desu ka? = Siapa ini? 
• Wakatta = Oke, ngerti. 
• Sou ne .. = Begitulah, Mungkin 
• Masaka.... = Nggak mungkin..... (ah masa .....) 
• Naru hodo = Oh gitu 
•Yokatta... = Syukurlah.... 
• Hontou ni?/Souka? = Bener gitu?
• Kimi wa boku no mono = kamu milikku
• Ki o tsukete ne = Hati-hati yah~ 
• Onaka ga suita = Aku lapar
• Itadakimassuuu = Selamat Makaaannn 
• Ii yume wo mite ne = Mimpi indah yah, 
• Yatta ! = Horee! 
• Kawaisou ni... = kasian... 
• Chotto matte ! = Tunggu bentar! 
• Uso = Bohong 
• Uso tsuki ! = Tukang bohong! 
• Uso Jyanai! = Jangan bohong! 
• Nan da yo!? = Apa kau!? 
• Damare! = Diammm! 
• Omae wa kankei nai darou.. ! = Bukan urusanmu..! 
• Mata ne / Mata yo ~ = Sampe jumpa~ 
 • Jibun no seida = Salah sendiri 
• Hitomebore datta no yo... = Cinta pada pandangan pertama
• Doki-doki shichatta yo... = Aku jadi deg-degan nih... 
• Suki da .. = Aku suka kamu 
• Kareshi ga iru no ? = Udah punya pacar? 
• Bukkoroshite yaru! = Akan kubunuh kau! (bisanya diucapkan kalau lagi pada berantem).

${gg} ${exists ? " exists " : "*[ Xryuu-BOT ]* 💕"}`, MessageType.text)
}
if(text.includes(".nhentai2")){
var num = text.replace(/!help/ , "")
var idn = num.replace("0","+62");

console.log(id);
const gg = idn+''

const exists = await conn.isOnWhatsApp (gg)
console.log(exists);
conn.sendMessage(id ,`╔ ═〘 *♥️NHENTAI ♥* 〙╗
Gampang Mode :
• https://nhentai.net/g/316755/
• https://nhentai.net/g/316596/
• https://nhentai.net/g/311850/
• https://nhentai.net/g/315578/
• https://nhentai.net/g/315488/
• https://nhentai.net/g/315406/
• https://nhentai.net/g/315344/
• https://nhentai.net/g/315323/
• https://nhentai.net/g/315136/
• https://nhentai.net/g/315099/

Medium Mode :
• https://nhentai.net/g/316867/
• https://nhentai.net/g/316869/
• https://nhentai.net/g/316785/
• https://nhentai.net/g/316763/51/
• https://nhentai.net/g/316445/
• https://nhentai.net/g/316250/
• https://nhentai.net/g/311283/
• https://nhentai.net/g/265671/
• https://nhentai.net/g/312127/
• https://nhentai.net/g/311560/

Hard Mode :
• https://nhentai.net/g/316820/
• https://nhentai.net/g/316481/
• https://nhentai.net/g/316430/
• https://nhentai.net/g/276347/
• https://nhentai.net/g/196329/
• https://nhentai.net/g/304543/
• https://nhentai.net/g/295295/
• https://nhentai.net/g/311262/
• https://nhentai.net/g/311882/
• https://nhentai.net/g/312180/
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Kodeu nuklir ti MILF Oneesan dugi ka bro ***** loli

https://nhentai.net/g/271890/
https://nhentai.net/g/272057/
https://nhentai.net/g/272173/
https://nhentai.net/g/272182/
https://nhentai.net/g/272196/
ht
https://nhentai.net/g/272512/
https://nhentai.net/g/271245/
https://nhentai.net/g/271056/
https://nhentai.net/g/270809/
https://nhentai.net/g/269653/
https://nhentai.net/g/266088/
https://nhentai.net/g/264980/
https://nhentai.net/g/262215/
https://nhentai.net/g/260433/

-

https://nhentai.net/g/260146/
https://nhentai.net/g/256738/
https://nhentai.net/g/272425/
https://nhentai.net/g/272352/
https://nhentai.net/g/272045/
https://nhentai.net/g/272015/
https://nhentai.net/g/271993/
https://nhentai.net/g/271924/
https://nhentai.net/g/271905/
https://nhentai.net/g/271797/

-

https://nhentai.net/g/271760/
https://nhentai.net/g/271717/
https://nhentai.net/g/271726/
https://nhentai.net/g/271667/
https://nhentai.net/g/267352/
https://nhentai.net/g/152968/
https://nhentai.net/g/238876/
https://nhentai.net/g/116395/
https://nhentai.net/g/84809/
https://nhentai.net/g/211656/

-

https://nhentai.net/g/272117/
https://nhentai.net/g/188721/
https://nhentai.net/g/266402/
https://nhentai.net/g/238876/
 Happy Mother's Day 165310,177978,211759,212643,229540, 250029,211519,256097,163478, 91505, 79280, 260629,128051,121972,261633,172044,119055,208323,149942,161236, 177150,233766,97949,230107 ,175822, 213545,232837,179166,138603,130183, 173543,234642,268015,228293,268893, 239536, yg suka mamah
Random
 257892 226942 236297 216039 221711 245304 166174 175220 244327 191049 220882 244859 227446 259328 259532 259634 259610 259348 258669 256097 118282 260028 260058 259557 259497 122220 260111 260088 259880 258977 260097 259765 259359 260138 259617 107965 197255 260276 260209 260210 260203 191360 191390 248933 257567 227913 211648 210240 260626 259622 257991 213966 260623 149112 257168 198203 114783 220958 244387 243734 223315 118069 136188 260686 241777  260912 142154 119798 261174 258301 256808 169134 220354 260271 261725 261378 252174 261928 114427 187003 147577 249458 157767 224316 175294 258450 233864 236128 261162 174036 187205 210873 193318 110232 199310 193816 220376 193814 193815 219068 220386 177642 188269 181837 220377 119293 257528 258926 262384 105951 259904 208174 249229 245644 262538 234818 216845 149212 134442 135927 262447 261811 261650 261225 261226 260761 250327 192327 167801 150309 123554

 https://www2.zippyshare.com/d/z9dcY6Nr/791216/%5bNekoPoi%5d_Akina_to_Onsen_de_H_Shiyo%5b360P%5d%5bnekopoi.care%5d.mp4
 https://www4.zippyshare.com/d/j7PFLGUY/946757/%5bNekoPoi%5d_Tsuma_ga_Kirei_ni_Natta_Wake_-_02_%5b360P%5d_%5bnekopoi.care%5d.mp4
 https://www111.zippyshare.com/d/EK5uqIMh/566060/%5bNekoPoi%5d_Megane_no_Megami_-_01_%5b360P%5d_%5bnekopoi.care%5d.mp4
 https://www109.zippyshare.com/d/2ebALhhS/463654/%5bNekoPoi%5d_Watashi_ga_Toriko_-_02%5b360P%5d%5bnekopoi.care%5d.mp4
 https://www115.zippyshare.com/d/LmzOkRAI/313299/%5bNekoPoi%5d_Chichi-iro_Toiki_-_01_%5b360P%5d%5bnekopoi.care%5d.mp4
 https://www89.zippyshare.com/d/SgEHvrJs/42812/%5bNekoPoi%5d_Chichi-iro_Toiki_-_02_%5b360P%5d%5bnekopoi.care%5d.mp4
 https://www66.zippyshare.com/d/j0ivbciL/520411/%5bNekoPoi%5d_Onna_Maou_Melissa_no_H_na_Boukenki_-_01_%5b360P%5d_%5bnekopoi.care%5d.mp4
 https://www71.zippyshare.com/d/M225YIrR/535656/%5bNekoPoi%5d_Buta_no_Gotoki_Sanzoku_ni_Torawarete_Shojo_wo_Ubawareru_Kyonyuu_Himekishi_Onna_Senshi_-_01%5b360P%5d%5bnekopoi.care%5d.mp4
 https://www49.zippyshare.com/d/bdwYjaXS/605790/%5bNekoPoi%5d_Akebi_no_Hana___Maho_-_01_%5b360P%5d_%5bnekopoi.pro%5d.mp4
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
● CODE NUKLIR ●
‌229144 253687 238577 236509
‌227675 229085 233245 266177
254351 265855 239842 219847
239749 230566 253104 230185
251974 253091 251489 238030
260614 245023 232887 233547
262158 262870 239312 255129
244530 246963 256050 215459
243725 233770 250704 261819
261830 215658 256404 260028
261789 241254 268580 262407
262252 201814 250193 236036
262889 243933 245697 239750
128983 95364 223815 225080
110332 225767 97247 231139
266116 217037 160657 182439
205089 176495 199121 199425
184068 186615 224644 129479
251524 153374 146499 258212
163532 255244 269825 235914
247103 138365 124624 219718
168941 265918 205995 191390
‌225496 259137 231681 161688
‌199613 259260 260433 235532 
‌88323 272117 170213 256613
‌258382 224942

/g/181556/ - Fudeoro Sisters
/g/152456/ - Mou Teitoku No Soba 
/g/167936/ - Inma Mo Mikata
/g/139048/ - shojo soushitsu
/g/185592/ - Gensoukyou Rakuenka Keikaku 11
/g/191427/ - Kousei Iinkai
/g/175015/ - Sister Breeder
/g/142825/ - A Certain Village
/g/182290/ - A hero taken prisoner
/g/192845/ - Toaru Natsu
/g/192849/ - Toaru Fuyu
/g/183099/ - Adolescent calculation
/g/192143/ - Blonde no koigokoro
/g/142825/ - Toaru mura no Fudeoroshi Jijou
/g/153856/ - Tenryuu Onee-chan fo naisho no Yasen Enshuu!!
/g/158404/ - Kusogaki
/g/136026/ - Megaflower x flower
/g/188918/ Kodomo no Ecchi
/g/193876/ - Razoku no Yoru
/g/193984/ - Houkago Rendezvous
/g/76119/ - Broadcast Girlfriend
/g/192874/ - Koyomi Fechi
/g/107180/ - Harem Bukai no Boku
/g/110900/ - Kiniro
/g/135193/ - It's my win!
/g/161488/ - Shota Teitoku to Nyuukyo Time
/g/65433/ - Jirettai no Yo!
/g/182327/ - Sakeno Seiton
/g/78651/ -  Harem Time
/g/190230/ - Boku no Bimama
/g/191880/ - Sanae Hamaru
/g/180600/ - Sakaki-san Satisfaction
/g/105465/ - Sakaki-san Franchise
/g/173023/ - Tiny Evil
/g/191049/ - Kono Suba 1
/g/191851/ - Kono Suba 2
/g/167112/ - i'll be your cat
/g/177754/ - Sloppy Sister
/g/187016/ - Nanyou no Vacances Sakusen
/g/165961/ - Love-ridden
/g/165962/ - Pandemonium
/g/97879/  - Natsuyasumi
/g/74500/ - Nee-chan no yobanaide
/g/133435/ - Spirited Girl
/g/152075/ - Trick And Treat
/g/174888/ - Razoku No Yoru
/g/93354/ - Melty Play
/g/74076/ - BAD COMMUNICATION
/g/122948/ - PLAY BACK
/g/104346/ - Funky Glamourous
/g/91773/ - Good Times!!
/g/78226/ - Practice Game
/g/76482/ - JOINT
/g/68508/ -  Kimi ga iru nara
/g/61224/ - Way back to the future
/g/60473/ - Hoshi ni negai o
/g/58469/ - Splash
/g/56295/ - Heat Island
/g/53905/ - I Beg You
/g/42383/ - Rumors
/g/187611/ - My Dear Maid
/g/190846/ - Tsukimi Dango
/g/158050/ - Muchimuchi
/g/83269/ - Only a taste for Onee-Chan
/g/146042/ - Bismarck wa Shounen Teitoku kara Seifuku
/g/178941/ - Kodomo-Sensei
/g/100401/ - Sister paradise
/g/35240/ - Eiken Lovers
/g/77415/ - Koinaka
/g/190900/ - Grazero Fantasy
/g/161819/ - Night Of Incest
/g/151132/ - Pet Na Ane No Shitsukekata
/g/147585/ - Anetsun Summer!
/g/136908/ - Man x Koi
/g/112907/ - Imouto x Swimming!
/g/125392/ - Joubutsu!
/g/174463/ - Hotizuma Miyuki-San
/g/159290/ - Mister Mistake
/g/137953/ - Hotondo Byouki
 /g/114053/ - Unknown Title 
 /g/78818/ - Furofuro!
 /g/15055/ - Demodori Mama
 /g/39876/ - Cherry Break
 /g/191427/ - Doutei Danshi Kousei Iinkai
 /g/192695/ - Costte Asobo.
 /g/192330/ - Level 1
 /g/191320/ - Kimi Ni Nara Dekiru
 /g/164434/ - MIDNIGHT PRINCESS
 /g/76813/ - Superior Cake
 /g/148669/ - Ohime-sama Gokko
 /g/144806/ - Youkai Watching
 /g/163698/ - Escalation
 /g/158559/ - Jiyuu de Kimama na Ore no Imouto
 /g/182210/ - Hatsujou Days
 /g/131428/ - Having Fun With The One That I Love
 /g/112853/ - Boku to Oneesan no Naisho
 /g/178594/ - Imouto no Oppai ga Marudashi Datta Hanashi 1
 /g/195665/ - Imouto no Oppai ga Marudashi Datta Hanashi 2
 /g/195092/ - Imouto no Oppai ga Marudashi Datta Hanashi 3
 /g/195093/ - Imouto no Oppai ga Marudashi Datta Hanashi 4
229144 253687 238577 236509
 ‌227675 229085 233245 266177
 254351 265855 239842 219847
 239749 230566 253104 230185
 251974 253091 251489 238030
 260614 245023 232887 233547
 262158 262870 239312 255129
 244530 246963 256050 215459
 243725 233770 250704 261819
 261830 215658 256404 260028
 261789 241254 268580 262407
 262252 201814 250193 236036
 262889 243933 245697 239750
 128983 95364 223815 225080
 110332 225767 97247 231139
 266116 217037 160657 182439
 205089 176495 199121 199425
 184068 186615 224644 129479
 251524 153374 146499 258212
 163532 255244 269825 235914
 247103 138365 124624 219718
 168941 265918 205995 191390
 ‌225496 259137 231681 161688
 ‌199613 259260 260433 235532
 ‌88323 272117 170213 256613
 ‌258382 224942 281261

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ● Milf ●
165310,177978,211759,212643,229540, 250029,211519,256097,163478, 91505, 79280, 260629,128051,121972,261633,172044,119055,208323,149942,161236, 177150,233766,97949,230107 ,175822, 213545,232837,179166,138603,130183, 173543,234642,268015,228293,268893, 239536, yg suka mamah
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    ● Random ●
257892 226942 236297 216039 221711 245304 166174 175220 244327 191049 220882 244859 227446 259328 259532 259634 259610 259348 258669 256097 118282 260028 260058 259557 259497 122220 260111 260088 259880 258977 260097 259765 259359 260138 259617 107965 197255 260276 260209 260210 260203 191360 191390 248933 257567 227913 211648 210240 260626 259622 257991 213966 260623 149112 257168 198203 114783 220958 244387 243734 223315 118069 136188 260686 241777  260912 142154 119798 261174 258301 256808 169134 220354 260271 261725 261378 252174 261928 114427 187003 147577 249458 157767 224316 175294 258450 233864 236128 261162 174036 187205 210873 193318 110232 199310 193816 220376 193814 193815 219068 220386 177642 188269 181837 220377 119293 257528 258926 262384 105951 259904 208174 249229 245644 262538 234818 216845 149212 134442 135927 262447 261811 261650 261225 261226 260761 250327 192327 167801 150309 123554
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     ● yg suka onee san ●
189833 12386 232747 186250 200330 63009 202662 66435 145071 6290 185596 121963 67356 157649 230109 243886 172138 126145 253850 144121 166315 197350 2611 19157 247791 239595 50074 1235 135474 258965 262816 195747 242247 252913 149760 139983 114692 151132 152089 144481 201031 169585 198203 240330 236896 88670 254499 169585 196783 194443 59284 249265 62287
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━281917
KUMPULAN KODE NUKLIR
270576
213340
237210/3
184644/
184212/
237987/
238657/
183994/5/
Nhentai.net/g/244044/5/
Nhentai.net/g/183603/
nhentai.net/g/189103/
Nhentai.net/g/183773/8/
Nhentai.net/g/271709/
Nhentai.net/g/271074 Kemonomimi Milf
Nhentai.net/g/270424 Atago Azurlane
Nhentai.net/g/236554 Kemonomimi Half Horse
Nhentai.net/g/238151 kemonomimi final fantasy
Nhentai.net/g/269354 kemono friends
Nhentai.net/g/239567 Cowgirl 
Nhentai.net/g/227556 Bird Girl
Nhentai.net/g/226184 Neko
Nhentai.net/g/225422 Racoon
Nhentai.net/g/268918 Lolikitsune
Nhentai.net/g/235660 Fox
‌229144 253687 238577 236509
‌227675 229085 233245 266177
254351 265855 239842 219847
239749 230566 253104 230185
251974 253091 251489 238030
260614 245023 232887 233547
262158 262870 239312 255129
244530 246963 256050 215459
243725 233770 250704 261819
261830 215658 256404 260028
261789 241254 268580 262407
262252 201814 250193 236036
262889 243933 245697 239750
128983 95364 223815 225080
110332 225767 97247 231139
266116 217037 160657 182439
205089 176495 199121 199425
184068 186615 224644 129479
251524 153374 146499 258212
163532 255244 269825 235914
247103 138365 124624 219718
168941 265918 205995 191390
‌225496 259137 231681 161688
‌199613 259260 260433 235532
‌88323 272117 170213 256613
‌258382 224942
https://nhentai.net/g/192237/ Watashi to
https://nhentai.net/g/134318/ Watashi no Onii-chan 1
https://nhentai.net/g/165279/ Watashi no Onii-chan 2
https://nhentai.net/g/164114/ Watashi no Onii-chan 3
https://nhentai.net/g/192347/ Watashi no Onii-chan 4
https://nhentai.net/g/209026/ Cocologic
https://nhentai.net/g/207432/ Watashi no Onii-chan 4,5
https://nhentai.net/g/247574/ Watashi no Onii-chan Extra
/g/181556/ - Fudeoro Sisters
/g/152456/ - Mou Teitoku No Soba
/g/167936/ - Inma Mo Mikata
/g/139048/ - shojo soushitsu
/g/185592/ - Gensoukyou Rakuenka Keikaku 11
/g/191427/ - Kousei Iinkai
/g/175015/ - Sister Breeder
/g/142825/ - A Certain Village
/g/182290/ - A hero taken prisoner
/g/192845/ - Toaru Natsu
/g/192849/ - Toaru Fuyu
/g/183099/ - Adolescent calculation
/g/192143/ - Blonde no koigokoro
/g/142825/ - Toaru mura no Fudeoroshi Jijou
/g/153856/ - Tenryuu Onee-chan fo naisho no Yasen Enshuu!!
/g/158404/ - Kusogaki
/g/136026/ - Megaflower x flower
/g/188918/ Kodomo no Ecchi
/g/193876/ - Razoku no Yoru
/g/193984/ - Houkago Rendezvous
/g/76119/ - Broadcast Girlfriend
/g/192874/ - Koyomi Fechi
/g/107180/ - Harem Bukai no Boku
/g/110900/ - Kiniro
/g/135193/ - It's my win!
/g/161488/ - Shota Teitoku to Nyuukyo Time
/g/65433/ - Jirettai no Yo!
/g/182327/ - Sakeno Seiton
/g/78651/ - Harem Time
/g/190230/ - Boku no Bimama
/g/191880/ - Sanae Hamaru
/g/180600/ - Sakaki-san Satisfaction
/g/105465/ - Sakaki-san Franchise
/g/173023/ - Tiny Evil
/g/191049/ - Kono Suba 1
/g/191851/ - Kono Suba 2
/g/167112/ - i'll be your cat
/g/177754/ - Sloppy Sister
/g/187016/ - Nanyou no Vacances Sakusen
/g/165961/ - Love-ridden
/g/165962/ - Pandemonium
/g/97879/ - Natsuyasumi
/g/74500/ - Nee-chan no yobanaide
/g/133435/ - Spirited Girl
/g/152075/ - Trick And Treat
/g/174888/ - Razoku No Yoru
/g/93354/ - Melty Play
/g/74076/ - BAD COMMUNICATION
/g/122948/ - PLAY BACK
/g/104346/ - Funky Glamourous
/g/91773/ - Good Times!!
/g/78226/ - Practice Game
/g/76482/ - JOINT
/g/68508/ - Kimi ga iru nara
/g/61224/ - Way back to the future
/g/60473/ - Hoshi ni negai o
/g/58469/ - Splash
/g/56295/ - Heat Island
/g/53905/ - I Beg You
/g/42383/ - Rumors
/g/187611/ - My Dear Maid
/g/190846/ - Tsukimi Dango
/g/158050/ - Muchimuchi
/g/83269/ - Only a taste for Onee-Chan
/g/146042/ - Bismarck wa Shounen Teitoku kara Seifuku
/g/178941/ - Kodomo-Sensei
/g/100401/ - Sister paradise
/g/35240/ - Eiken Lovers
/g/77415/ - Koinaka
/g/190900/ - Grazero Fantasy
/g/161819/ - Night Of Incest
/g/151132/ - Pet Na Ane No Shitsukekata
/g/147585/ - Anetsun Summer!
/g/136908/ - Man x Koi
/g/112907/ - Imouto x Swimming!
/g/125392/ - Joubutsu!
/g/174463/ - Hotizuma Miyuki-San
/g/159290/ - Mister Mistake
/g/137953/ - Hotondo Byouki
/g/114053/ - Unknown Title 
/g/78818/ - Furofuro!
/g/15055/ - Demodori Mama
/g/39876/ - Cherry Break
/g/191427/ - Doutei Danshi Kousei Iinkai
/g/192695/ - Costte Asobo.
/g/192330/ - Level 1
/g/191320/ - Kimi Ni Nara Dekiru
/g/164434/ - MIDNIGHT PRINCESS
/g/76813/ - Superior Cake
/g/148669/ - Ohime-sama Gokko
/g/144806/ - Youkai Watching
/g/163698/ - Escalation
/g/158559/ - Jiyuu de Kimama na Ore no Imouto
/g/182210/ - Hatsujou Days
/g/131428/ - Having Fun With The One That I Love
/g/112853/ - Boku to Oneesan no Naisho
/g/178594/ - Imouto no Oppai ga Marudashi Datta Hanashi 1
/g/195665/ - Imouto no Oppai ga Marudashi Datta Hanashi 2
/g/195092/ - Imouto no Oppai ga Marudashi Datta Hanashi 3
/g/195093/ - Imouto no Oppai ga Marudashi Datta Hanashi 4
/g/183714/ - Mating With Oni 1
/g/181008/ - Mating With Oni 2
/g/176948/ - Gal Shota Cinderella 1
/g/178511/ - Gal Shota Cinderella 2
/g/185653/ - Gal Shota Cinderella 3
/g/137236/ - Mika-ppoi no! 1
/g/144128/ - Mika-ppoi no! 2
/g/3508/ - Shounen Teikoku 1
/g/3509/ -Shounen Teikoku 2
/g/3510/ - Shounen Teikoku 3
/g/3511/ - Shounen Teikoku 5''
/g/3512/ -Shounen Teikoku 5
/g/3262/ Shounen Teikoku 6
/g/3466/ - Shounen Teikoku 7
/g/2598/ - Shounen Teikoku 8
/g/8196/ - Shounen Teikoku 9
/g/185406/ - Ane Zukushi 1-11
/g/188848/ - Perfect Half (long)
Ordinary Guy: 198964 Countryside 
104436 Mismatched Thoughts
213681 Cultivating Bigger Pleasure
242460 Bokujou: Happy End
255869 Today, Surely
116018 Kahanshin No Otsukiai
165310 Suki Suki! Okaa-san
187047 Shirasaka Koume To No Kankei
116272 Akiko-san To Issho
274000 Hame Kama
93335 Henkano 
165961 Love-Ridden 
250500 Koishi-chan No Bitch Na Hon
264061 Idol Refle Sex
110896 Uchi No Imouto Ga Sukoshi Kawaii
187095 Nuki & Koki
32591 Kosu Tora
151436 FuckBuddy Collection
231188 Minatsu's Fault
275485 Nurunuru Deriheru
275306 Sweet Whispers
205199 Most Distant Neighbor
274796 The Drunk Mouth Of My Neighbor
274412 Kyousei Zecchou Batsu Game
71646 Otonashi Kotorisan
273719 Oshiri Ai
273849 Strength and III
120744 PuniKano
172759 Dogful Days
273337 I Will Serve You Tonight
273132 Watanabe's Day Off
273222 Koukando Analyze!
272129 Dog & Cat Roleplay
271958 Enemy Girl
271892 Poolside Reward
217727 Uruka-chan To Ichaicha Shitai!
271431 Toshoshitsu O Shimete Kara
271282 Hidden Quest
270752 Natsu Ni   Ecc
${gg} ${exists ? " exists " : "*[ Xryuu-BOT ]* 💕"}`, MessageType.text)
}
if(text.includes(".listzodiak")){
var num = text.replace(/!help/ , "")
var idn = num.replace("0","+62");

console.log(id);
const gg = idn+''

const exists = await conn.isOnWhatsApp (gg)
console.log(exists);
conn.sendMessage(id ,`╭───「 *ZODIAK LIST* 」
├≽  Zodiak Aries (21 Maret – 20 April)
├≽ ️Zodiak Taurus (21 April – 20 Mei)
├≽ ️Zodiak Gemini (21 Mei – 20 Juni)
├≽ ️Zodiak Cancer (21 Juni – 20 Juli)
├≽ ️Zodiak Leo (21 Juli – 21 Agustus)
├≽ ️Zodiak Virgo (22 Agustus – 22 September)
├≽ ️Zodiak Libra (23 September – 22 Oktober)
├≽ ️Zodiak Scorpio (23 Oktober – 22 November)
├≽ ️Zodiak Sagittarius (23 November – 20 Desember)
├≽ ️Zodiak Capricorn (21 Desember – 19 Januari)
├≽ ️Zodiak Aquarius (20 Januari – 18 Februari)
├≽ ️Zodiak Pisces (19 Februari – 20 Maret)
╰───────── ${gg} ${exists ? " " : "*Thank for Using Xryuu-BOT* 💕"}`, MessageType.text)
}
if (text.includes('.tts2')){
  var teks = text.replace(/.tts2 /, '')
    axios.get('http://scrap.terhambar.com/tts?kata=${teks}')
    .then((res) => {
      audioToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[WAIT] Searching...❗', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.audio)
        })
    })
}

if (text.includes(".say")){
  const teks = text.replace(/.say /, "")
conn.sendMessage(id, teks, MessageType.text)
}

if (text.includes(".ytmp4")) {
const teks = text.replace(/.ytmp4 /, "")
		var url = 'https://st4rz.herokuapp.com/api/ytv2?url=' + teks
        axios.get(url)
            .then(res => {
            	conn.sendMessage(id, '[WAIT]Sedang Mencari Link Yang Anda cari🔎', MessageType.text)
 imageToBase64(res.data.thumb)
                .then(
            (response) => {
            	
	var buf = Buffer.from(response, 'base64'); 
const { BitlyClient } = require('bitly');
const bitly = new BitlyClient('5ed1151721e9e8b878940031822091b078b406cd', {});
bitly
  .shorten(res.data.result)
  .then(function(result) {
    console.log(result);
    conn.sendMessage(id , buf , MessageType.image, { caption: `Judul : ${res.data.title}\n\nLink : ${result.link}`, quoted: m })
  })
  .catch(function(error) {
    console.error(error);
  });
  })
	})
	}
if (text == '.closegc' || text == '.closegrup'){
		if (!isGroup) return conn.sendMessage(id, "Ini Bukan Grup Bodo!", MessageType.text , { quoted: m })
		if (!isBotGroupAdmins) return conn.sendMessage(id, "Bot Tidak Menjadi Admin Silakan Adminkan Untuk Bisa Menggunakan Fitur Ini", MessageType.text , { quoted: m })
		if (!isGroupAdmins) return conn.sendMessage(id, "Kamu Bukan Admin!", MessageType.text , { quoted: m })
 let hasil = `${id.split("@s.whatsapp.net")[0]}`;
   conn.groupSettingChange (hasil, GroupSettingChange.messageSend, true);
conn.sendMessage(id, 'Grup Telah Di Tutup' ,MessageType.text, { quoted: m } );
}
if (text == '.opengc' || text == '.opengrup'){
		if (!isGroup) return conn.sendMessage(id, "Ini Bukan Grup Bodo!", MessageType.text , { quoted: m })
		if (!isBotGroupAdmins) return conn.sendMessage(id, "Bot Tidak Menjadi Admin Silakan Adminkan Untuk Bisa Menggunakan Fitur Ini", MessageType.text , { quoted: m })
		if (!isGroupAdmins) return conn.sendMessage(id, "Kamu Bukan Admin!", MessageType.text , { quoted: m })
let hasil = `${id.split("@s.whatsapp.net")[0]}`;
   conn.groupSettingChange (hasil, GroupSettingChange.messageSend, false);
conn.sendMessage(id, 'Grup Telah Di Buka' ,MessageType.text, { quoted: m } );
}
if (text.includes(".bitly")){
const teks = text.replace(/.bitly /, "")
const { BitlyClient } = require('bitly');
const bitly = new BitlyClient('Pake Token sendiri ya asw', {});
 
bitly
  .shorten(teks)
  .then(function(result) {
    console.log(result);
    conn.sendMessage(id , result.link, MessageType.text, { quoted: m })
  })
  .catch(function(error) {
    console.error(error);
  });
  }
				if (text == ".tagall") {
members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					no = 0
					teks += '\n\n'
					for (let mem of groupMembers) {
						no += 1
						teks += `${no.toString()}.@${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
}
				if (text.includes(".clearall")){
					if (!isOwner) return conn.sendMessage(id, "koe owner ya?", MessageType.text , { quoted: m })
					anu = await conn.chats.all()
					conn.setMaxListeners(25)
					for (let _ of anu) {
						conn.deleteChat(_.jid)
					}
						conn.sendMessage(id ,'Berhasil', MessageType.text)
					
				}
			      if (text.includes(".block")){
					if (!isGroup) return conn.sendMessage(id, "Ini Bukan Grup Bodo!", MessageType.text , { quoted: m })
					if (!isOwner) return conn.sendMessage(id, "Koe owner ya?", MessageType.text , { quoted: m })
					conn.blockUser (`${body.slice(7)}@c.us`, "add")
					conn.sendMessage(from, `𝗽𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝗗𝗶𝘁𝗲𝗿𝗶𝗺𝗮, 𝗺𝗲𝗺𝗯𝗹𝗼𝗸𝗶𝗿 ${body.slice(7)}@c.us`, text)
					
			      }
                     if (text.includes(".unblock")){
					if (!isGroup) return conn.sendMessage(id, "Ini Bukan Grup Bodo!", MessageType.text , { quoted: m })
					if (!isOwner) return conn.sendMessage(id, "Koe owner ya?", MessageType.text , { quoted: m })
				    conn.blockUser (`${body.slice(9)}@c.us`, "remove")
					conn.sendMessage(from, `𝗽𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝗗𝗶𝘁𝗲𝗿𝗶𝗺𝗮, 𝗺𝗲𝗺𝗯𝘂𝗸𝗮 ${body.slice(9)}@c.us`, text)
				
		     }
				 if (text.includes(".leave")){
				if (!isGroup) return conn.sendMessage(id, "Ini Bukan Grup Bodo!", MessageType.text , { quoted: m })
					if (!isOwner) return conn.sendMessage(id, "Koe owner ya?", MessageType.text , { quoted: m })
				await conn.client.leaveGroup(from, '𝗕𝘆𝗲𝗲', groupId)
	
				 }
				 if (text.includes(".bc")){
					if (!isOwner) return conn.sendMessage(id, "Koe owner ya?", MessageType.text , { quoted: m })
					if (args.length < 1) return reply('.......')
					anu = await client.chats.all()
					if (isMedia && !mek.message.videoMessage || isQuotedImage) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						buff = await conn.downloadMediaMessage(encmedia)
						for (let _ of anu) {
							conn.sendMessage(_.jid, buff, image, {caption: `❮ 𝙋𝙀𝙎𝘼𝙉 𝘽𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏 ❯\n\n${body.slice(4)}`})
						}
						reply('𝙨𝙪𝙘𝙘𝙚𝙨𝙨 𝙗𝙧𝙤𝙖𝙙𝙘𝙖𝙨𝙩 ')
					} else {
						for (let _ of anu) {
							sendMess(_.jid, `❮ 𝙋𝙀𝙎𝘼𝙉 𝘽𝙍𝙊𝘼𝘿𝘾𝘼𝙎𝙏 ❯\n\n${body.slice(4)}`)
						}
						conn.sendMessage(id ,'Berhasil', MessageType.text)
					}
				 }
if (text.includes('.randomhentai')){
  var teks = text.replace(/.randomhentai /, '')
    axios.get(`https://tobz-api.herokuapp.com/api/hentai`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
		  conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
        })
    })
}
if (text.includes(".jam")){
const adam = text.replace(/.jam /, "")
axios.get(`https://rest.farzain.com/api/jam.php?id=${adam}&apikey=e5a6CtIFd4ACxYzMKT76t5rkW`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Jam Berapa di negara tersebut', MessageType.text)
    let hasil = `Nih Jam ${adam} kak \n\n* Tanggal:* ${res.data.time.date}\n* Waktu :* ${res.data.time.time}\n* Tempat :* ${res.data.location.address}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}
if (text.includes(".tagall")){
members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					no = 0
					teks += '\n\n'
					for (let mem of groupMembers) {
						no += 1
						teks += `${no.toString()}.@${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
}
if (text.includes('.creator')){
conn.sendMessage(id, {displayname: "Jeff", vcard: vcard}, MessageType.contact)
conn.sendMessage(id, 'Ingin Masukin bot ke grup???, bisa chat owner dengan cara . owner / . creator ;-;', MessageType.text)
}
if (text.includes('.owner')){
conn.sendMessage(id, {displayname: "Jeff", vcard: vcard}, MessageType.contact)
conn.sendMessage(id, 'Ingin Masukin bot ke grup???, bisa chat owner dengan cara . owner / . creator ;-;', MessageType.text)
}
if (text == ".ping") {
const speed = require("performance-now")
const timestamp = speed();
	const latensi = speed() - timestamp
	conn.sendMessage(id, `Speed ${latensi.toFixed(4)} Second`, MessageType.text, { quoted: m })
}
if (text == ".quotesanime") {
const teks = text.replace(/.quotesanime /, "")
axios.get(`https://animechanapi.xyz/api/quotes?anime=${teks}`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Quotes🔎', MessageType.text)
    let hasil = `quotesanime\n\n${res.data.quote} *character* \n${res.data.character} *anime* \n${res.data.anime}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".harinasional")){
const teks = text.replace(/.harinasional /, "")
axios.get(`https://api.haipbis.xyz/harinasional?tanggal=${teks}`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Hari Yang Anda cari🔎', MessageType.text)
    let hasil = `➸  *Tanggal : ${res.data.tanggal}*\n\n➸ keterangan : ${res.data.keterangan}`;
    conn.sendMessage(id, hasil ,MessageType.text);
  })
 }
if (text.includes('.cooltext')){
  var teks = text.replace(/.cooltext /, '')
    axios.get('https://api.haipbis.xyz/randomcooltext?text='+teks)
    .then((res) => {
      imageToBase64(res.data.image)
        .then(
          (ress) => {
            conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
} 
if (text.includes('.map')){
  var teks = text.replace(/.map /, '')
    axios.get('https://mnazria.herokuapp.com/api/maps?search='+teks)
    .then((res) => {
      imageToBase64(res.data.gambar)
        .then(
          (ress) => {
            conn.sendMessage(id, '[WAIT]Sedang Mencari Map Yang Anda cari🔎', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image,  {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
        })
    })
}
if (text.includes('.nsfwneko')){
  var teks = text.replace(/.nsfwneko /, '')
    axios.get(`https://tobz-api.herokuapp.com/api/nsfwneko`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
		  conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
        })
    })
}
if (text.includes('.nsfwtrap')){
  var teks = text.replace(/.nsfwtrap /, '')
    axios.get(`https://tobz-api.herokuapp.com/api/nsfwtrap`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
		  conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
        })
    })
}
if (text.includes('.nsfwblowjob')){
  var teks = text.replace(/.nsfwblowjob /, '')
    axios.get(`https://tobz-api.herokuapp.com/api/nsfwblowjob`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
		  conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
        })
    })
}
if (text.includes('.wolf')){
var porn = text.split(".wolf ")[1];
    var text1 = porn.split("|")[0];
    var text2 = porn.split("|")[1];
    axios.get(`https://tobz-api.herokuapp.com/api/textpro?theme=wolflogo1&text1=${text1}&text2=${text2}`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
		  conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
        })
    })
}
if (text.includes('.gaming')){
  var teks = text.replace(/.gaming /, '')
    axios.get(`https://docs-jojo.herokuapp.com/api/gaming?text=${teks}`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
		  conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
        })
    })
}
if (text.includes('.animehug')){
  var teks = text.replace(/.animehug /, '')
    axios.get(`https://tobz-api.herokuapp.com/api/hug`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
		  conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
        })
    })
}
if (text.includes('.gltext')){
var gh = text.split(".gltext ")[1];
    var teks1 = gh.split("|")[0];
    var teks2 = gh.split("|")[1];
    axios.get(`http://inyourdream.herokuapp.com/glitch?kata1=${teks1}&kata2=${teks2}`).then((res) => {
      imageToBase64(res.data.status)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text, { quoted: m })
            conn.sendMessage(id, buf, MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
        })
    })
}
if (text.includes('.pornhub')){
var porn = text.split(".pornhub ")[1];
    var text1 = porn.split("|")[0];
    var text2 = porn.split("|")[1];
    axios.get(`https://mhankbarbars.herokuapp.com/api/textpro?theme=pornhub&text1=${text1}&text2=${text2}`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text, { quoted: m })
            conn.sendMessage(id, buf, MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
        })
    })
}
if (text.includes('.animecry')){
  var teks = text.replace(/.animecry /, '')
    axios.get(`https://tobz-api.herokuapp.com/api/cry`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
		  conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
        })
    })
}
if (text.includes(".linkgc")){
const code = await conn.groupInviteCode (id.split("@s.whatsapp.net")[0])

conn.sendMessage(id, "https://chat.whatsapp.com/" + code , MessageType.text, { quoted: m })

}
if (text.includes(".setname")){
const teks = text.replace(/.setname /, "")

if (!isGroup) return conn.sendMessage(id, "Ini Bukan Grup Bodo!", MessageType.text , { quoted: m })
		if (!isBotGroupAdmins) return conn.sendMessage(id, "Bot Tidak Menjadi Admin Silakan Adminkan Untuk Bisa Menggunakan Fitur Ini", MessageType.text , { quoted: m })
		if (!isGroupAdmins) return conn.sendMessage(id, "Kamu Bukan Admin!", MessageType.text , { quoted: m })
    let nama = `${teks}`;
    let idgrup = `${id.split("@s.whatsapp.net")[0]}`;
    conn.groupUpdateSubject(idgrup, nama);
conn.sendMessage(id, 'Berhasil Mengganti nama Grup⚔️' ,MessageType.text, { quoted: m } );

}
else if (text == '.quran'){
axios.get('https://api.banghasan.com/quran/format/json/acak').then((res) => {
    const sr = /{(.*?)}/gi;
    const hs = res.data.acak.id.ayat;
    const ket = `${hs}`.replace(sr, '');
    let hasil = `[${ket}]   ${res.data.acak.ar.teks}\n\n${res.data.acak.id.teks}(QS.${res.data.surat.nama}, Ayat ${ket})`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (messageType == 'imageMessage')
   {
       let caption = imageMessage.caption.toLocaleLowerCase()
       if (caption == '.ocr')
       {
           const img = await conn.downloadAndSaveMediaMessage(m)
           readTextInImage(img)
               .then(data => {
                   console.log(data)
                   conn.sendMessage(id, `${data}`, MessageType.text);
               })
               .catch(err => {
                   console.log(err)
               })
       }
   }
if (text.includes(".textimage")){
const teks = text.replace(/.textimage /, "")
axios.get(`https://api.haipbis.xyz/randomcooltext?text=${teks}`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
    let hasil = `Text Image Succes :) \n\n${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".wikien")){
const teks = text.replace(/.wikien /, "")
axios.get(`https://arugaz.herokuapp.com/api/wikien?q=${teks}`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
    let hasil = ` *👩‍💻According to Wikipedia:👩‍💻* \n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes('.pemilikasli')){
conn.sendMessage(id, {displayname: "Jeff", vcard: vcard}, MessageType.contact)
conn.sendMessage(id, 'Ingin Mskin bot ke grup???, bisa chat owner ;-;', MessageType.text)
}
if (text.includes(".neknime")) {
  const teks = text.replace(/.neknime /, "")
  axios.get(`https://st4rz.herokuapp.com/api/nekonime`).then((res) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
    let hasil = ` *Nih animenya :)*\n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil, MessageType.text);
  })
}
if (text.includes(".zodiak")){
const teks = text.replace(/.zodiak /, "")
axios.get(`https://arugaz.herokuapp.com/api/getzodiak?nama=aruga&tgl-bln-thn=${teks}`).then((res) => {
    let hasil = `➡️ Lahir : ${res.data.lahir}*\n➡ ️ultah : ${res.data.ultah}\n➡ ️usia : ${res.data.usia}\n➡ zodiak : ${res.data.zodiak}️`;
    conn.sendMessage(id, hasil ,MessageType.text);
  })
 }
if (text.includes(".namajenis")){
const teks = text.replace(/.namajenis /, "")
axios.get(`https://api.terhambar.com/nama?jenis=${teks}`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
    let hasil = `namajeniskalian\n nama : {res.data.nama}\n${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".covidall")){
const teks = text.replace(/.coronainfoall /, "")
axios.get(`https://api.terhambar.com/negara/World`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Data Covid Yang Anda cari🔎', MessageType.text)
    let hasil = `info corona all \n\n *negara* : _${res.data.negara}_ \n *total* : _${res.data.total}_ \n *kasus_baru* : _${res.data.kasus_baru}_ \n *meninggal* : _${res.data.meninggal}_ \n *meninggal_baru* : _${res.data.meninggal_baru}_ \n *sembuh* : _${res.data.sembuh}_ \n *penanganan* : _${res.data.penanganan}_ \n *terakhir* : _${res.data.terakhir}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".dewabatch")){
const teks = text.replace(/.dewabatch /, "")
axios.get(`https://alfians-api.herokuapp.com/api/dewabatch?q=${teks}`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
    let hasil = `Anime Nya nih :) \n\n${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".gay")){
const teks = text.replace(/.gay /, "")
axios.get(`https://arugaz.herokuapp.com/api/howgay`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Berapa Persen Gay Anda🔎', MessageType.text)
    let hasil = ` ${res.data.desc} \n\n *Persen Gay Lo!!!* _${res.data.persen}_`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".yan")){
const teks = text.replace(/.yan /, "")
axios.get(`https://st4rz.herokuapp.com/api/simsimi?kata=${teks}`).then((res) => {
    let hasil = `${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".puisi1")){
const teks = text.replace(/.puisi1 /, "")
axios.get(`https://arugaz.herokuapp.com/api/puisi1`).then((res) => {
conn.sendMessage(id, '[WAIT]Sedang Mencari Puisi Yang Anda cari🔎', MessageType.text)
    let hasil = ` *Nih Puisinya Kak :)*\n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".puisi2")){
const teks = text.replace(/.puisi2 /, "")
axios.get(`https://arugaz.herokuapp.com/api/puisi3`).then((res) => {
conn.sendMessage(id, '[WAIT]Sedang Mencari Puisi Yang Anda cari🔎', MessageType.text)
    let hasil = ` *Nih Puisinya Kak :)*\n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".cerpen")){
const teks = text.replace(/.cerpen /, "")
axios.get(`https://arugaz.herokuapp.com/api/cerpen`).then((res) => {
conn.sendMessage(id, '[WAIT]Sedang Mencari Cerpen Yang Anda cari🔎', MessageType.text)
    let hasil = ` *Nih cerpen Kak :)*\n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".cersex")){
const teks = text.replace(/.cersex /, "")
axios.get(`https://arugaz.herokuapp.com/api/cersex2`).then((res) => {
conn.sendMessage(id, '[WAIT]Sedang Mencari Cersex Yang Anda cari🔎', MessageType.text)
    let hasil = ` *Nih cersex Kak :)*\n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".cersex2")){
const teks = text.replace(/.cersex2 /, "")
axios.get(`https://arugaz.herokuapp.com/api/cersex1`).then((res) => {
conn.sendMessage(id, '[WAIT]Sedang Mencari Cersex Yang Anda cari🔎', MessageType.text)
    let hasil = ` *Nih cersex Kak :)*\n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".quotes1")){
const teks = text.replace(/.quotes1 /, "")
axios.get(`https://arugaz.herokuapp.com/api/randomquotes`).then((res) => {
conn.sendMessage(id, '[WAIT]Sedang Mencari Quotes Yang Anda cari🔎', MessageType.text)
    let hasil = ` *Nih Quotes Kak :)*\n\n *Author* : _${res.data.author}_ \n\n *Quotes* : _${res.data.quotes}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".infoanime")){
const teks = text.replace(/.infoanime /, "")
axios.get(`https://arugaz.herokuapp.com/api/dewabatch?q=${teks}`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Infoanime Yang Anda cari🔎', MessageType.text)
    let hasil = ` INFO ANIME ${teks} : \n\n ${res.data.result} `;
imageToBase64(res.data.thumb) 
        .then(
            (response) => {    
	var buf = Buffer.from(response, 'base64'); 
    conn.sendMessage(id, buf ,MessageType.image, { caption: hasil });
})
})
}
if (text.includes('.tagme')) {
 var nomor = m.participant
 const options = {
       text: `@${nomor.split("@s.whatsapp.net")[0]} Berhasil Di Tag⚔️`,
       contextInfo: { mentionedJid: [nomor] }
 }
 conn.sendMessage(id, options, MessageType.text)
}
if (text.includes('.all')) {
 var nomor = m.participant
 const options = {
       text: `@${nomor.split("@a.whatsapp.net")[0]} tagged!`,
       contextInfo: { mentionedJid: [nomor] }
 }
 conn.sendMessage(id, options, MessageType.text)
}
if (text.includes(".otakudesu")){
const teks = text.replace(/.otakudesu /, "")
const animes =  axios.get(`https://mhankbarbar.herokuapp.com/api/otakudesu?q=${teks}&apiKey=F0Zuy3oCaQogy9MOt3tk`).then((res) => {
    let hasil = ` *Nih Anime Nya :)*\n\n _${animes.data.title}\n\n${animes.data.info}\n\n${animes.data.sinopsis}_ `;
    conn.sendMessage(from, animes.data.thumb, 'otakudesu.jpg', hasil, MessageType.text);
})
}
if (text.includes(".spamcall")){
const teks = text.replace(/.spamcall /, "")
axios.get(`https://arugaz.herokuapp.com/api/spamcall?no=${teks}`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Nomor Yang Anda cari🔎', MessageType.text)
    let hasil = ` *INFO SPAM CALL* \n\n _${res.data.logs}_`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".bucin")){
const teks = text.replace(/.bucin /, "")
axios.get(`https://arugaz.herokuapp.com/api/howbucins`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Kata Bucin Yang Anda cari🔎', MessageType.text)
    let hasil = ` _${res.data.desc}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".spamsms")){
const teks = text.replace(/#spamsms /, "")
axios.get(`https://arugaz.herokuapp.com/api/spamsms?no=${teks}&jum=20`).then((res) => {
	conn.sendMessage(id, '[WAIT] Proses...❗', MessageType.text)
    let hasil = ` *INFO SPAM SMS 20 PESAN* \n\n _${res.data.logs}_`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".indohot")){
const teks = text.replace(/.indohot /, "")
axios.get(`https://arugaz.herokuapp.com/api/indohot`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Info Ig Yang Anda cari🔎', MessageType.text)
    let hasil = ` *18+* \n\n *Judul* :  ${res.data.result.judul} \n\n *Status* :  ${res.data.result.genre} \n\n *Durasi* :  ${res.data.result.durasi} \n\n *Link* :  ${res.data.result.url} `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".filmanime")){
const teks = text.replace(/.filmanime /, "")
axios.get(`https://arugaz.herokuapp.com/api/sdmovie?film=${teks}`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Info Ig Yang Anda cari🔎', MessageType.text)
    let hasil = ` *Film Anime ${teks} :* \n\n *Judul* :  ${res.data.result.title} \n\n *Rating* :  ${res.data.result.rating} \n\n *Info* :  ${res.data.result.sinopsis} \n\n *Link Video* :  ${res.data.result.video} `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes('.infoig')){
  var teks = text.replace(/.infoig /, '')
    axios.get('https://arugaz.herokuapp.com/api/stalk?username='+teks)
    .then((res) => {
      imageToBase64(res.data.Profile_pic)
        .then(
          (ress) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Info Ig Yang Anda cari🔎', MessageType.text)
           let hasil = `Akun Sudah Ditemukan🥰!!\n\n*➸ Nama :* ${res.data.Name}\n*➸ Username :* ${res.data.Username}\n*➸ Followers :* ${res.data.Jumlah_Followers}\n*➸ Mengikuti :* ${res.data.Jumlah_Following}\n*➸ Jumlah Post :* ${res.data.Jumlah_Post}\n*➸ Bio :* ${res.data.Biodata}`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
        })
    })
}
if (text.includes('.infogempa')){
var teks = text.replace(/.infogempa /, '')
    axios.get(`https://st4rz.herokuapp.com/api/infogempa`).then((res) => {
      imageToBase64(res.data.map)
        .then(
          (ress) => {
          let hasil = `INFO GEMPA TERBARU DI INDONESIA\n\n*➸ Pusat Gempa :* ${res.data.lokasi}\n*➸ Koordinat :* ${res.data.koordinat}\n*➸ Waktu :* ${res.data.waktu}\n*➸ Magnitudo :* ${res.data.magnitude}\n*➸ Kedalaman :* ${res.data.kedalaman}\n*➸ Potensi :* ${res.data.potensi}`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, '[WAIT]Sedang Mencari Info Gempa Terbaru🔎', MessageType.text, { quoted: m })
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
        })
    })
}
if (text.includes(".katabijak")){
const teks = text.replace(/.katabijak /, "")
axios.get(`https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/random/katabijax.txt${teks}`).then((res) => {
    let hasil = `katabijak tersedia\n👇👇👇👇👇👇👇👇👇\n\nJudul: ${res.data.title}\n\katabijak Tersedia: ${res.data.filesize}\n\nLink: ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes(".twt")){
const teks = text.replace(/.twt /, "")
axios.get(`https://mhankbarbar.herokuapp.com/api/twit?url=${teks}&apiKey=zFuV88pxcIiCWuYlwg57`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Info Ig Yang Anda cari🔎', MessageType.text)
    let hasil = `âœ…Berhasil$ silahkan klik link di bawah untuk mendownload hasilnya$\nKlik link dibawahðŸ—¡ï¸\n\nSize: ${res.data.filesize}\n\nLink: ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes(".tts")){
const teks = text.replace(/.tts /, "")
const gtts = (`https://rest.farzain.com/api/tts.php?id=${teks}&apikey=O8mUD3YrHIy9KM1fMRjamw8eg`)
    conn.sendMessage(id, gtts ,MessageType.text);
}

if (text.includes(".tiktok")) {
const tictoc = text.replace(/.tiktok /, "")
axios.get(`http://scrap.terhambar.com/tiktokfull?link=${tictoc}`).then((res) => {
	 conn.sendMessage(id, '[WAIT]Sedang Mencari Info Ig Yang Anda cari🔎', MessageType.text)
     let titoe = `âœ…Berhasil$$$ Silahkan klik link dibawah ini untuk mendownload hasilnya$ \nKlik link dibawahðŸ—¡ï¸\n\nJudul: ${res.data.deskripsi} \n\nDurasi: ${res.data.durasi}\n\nNama: ${res.data.nama}\n\nUrl: ${res.data.urlvideo}`;
conn.sendMessage(id, titoe, MessageType.text);
})
}

if (text.includes(".setdesc")){
const teks = text.replace(/.setdesc /, "")
  if (!isGroup) return conn.sendMessage(id, "Ini Bukan Grup Bodo!", MessageType.text , { quoted: m })
		if (!isBotGroupAdmins) return conn.sendMessage(id, "Bot Tidak Menjadi Admin Silakan Adminkan Untuk Bisa Menggunakan Fitur Ini", MessageType.text , { quoted: m })
		if (!isGroupAdmins) return conn.sendMessage(id, "Kamu Bukan Admin!", MessageType.text , { quoted: m })
    let desk = `${teks}`;
    let idgrup = `${id.split("@s.whatsapp.net")[0]}`;
    conn.groupUpdateDescription(idgrup, desk)
conn.sendMessage(id, 'Berhasil Menganti desc Grup⚔️' ,MessageType.text, { quoted: m } );
}

if (text.includes(".ig")){
const teks = text.replace(/.ig /, "")
axios.get(`https://alfians-api.herokuapp.com/api/ig?url=${teks}`).then((res) => {
    let hasil = `Dwonload sendiri,link\n\nLink: ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes(".wiki")){
const teks = text.replace(/.wiki /, "")
axios.get(`https://arugaz.herokuapp.com/api/wiki?q=${teks}`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Info Ig Yang Anda cari🔎', MessageType.text)
    let hasil = `ðŸ“Menurut Wikipedia:\n\n${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

if (text.includes(".sholat")){
  const teks = text.replace(/.sholat /, "")
  axios.get(`https://api.haipbis.xyz/jadwalsholat?daerah=${teks}`).then ((res) =>{
  conn.sendMessage(id, '[WAIT]Sedang Mencari Info Ig Yang Anda cari🔎', MessageType.text)
  let hasil = `Jadwal sholat di ${teks} hari ini adalah\n\nâš¡Imsyak : ${res.data.Imsyak}\nâš¡Subuh : ${res.data.Subuh} WIB\nâš¡Dzuhur : ${res.data.Dzuhur}WIB\nâš¡Ashar : ${res.data.Ashar} WIB\nâš¡Maghrib : ${res.data.Maghrib}\nâš¡Isya : ${res.data.Isya} WIB\nâš¡Tengah malam : ${res.data.Dhuha} WIB`;
  conn.sendMessage(id, hasil, MessageType.text);
})
}
else if (text == '.quran'){
axios.get('https://api.banghasan.com/quran/format/json/acak').then((res) => {
    const sr = /{(.*?)}/gi;
    const hs = res.data.acak.id.ayat;
    const ket = `${hs}`.replace(sr, '');
    let hasil = `[${ket}]   ${res.data.acak.ar.teks}\n\n${res.data.acak.id.teks}(QS.${res.data.surat.nama}, Ayat ${ket})`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".infoanime2")){
const teks = text.replace(/.infoanime2 /, "")
axios.get(`https://arugaz.herokuapp.com/api/dewabatch?q=${teks}`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Info Ig Yang Anda cari🔎', MessageType.text)
    let hasil = ` *INFO ANIME ${teks} :* \n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes(".namaninja")){
const teks = text.replace(/.namaninja /, "")
axios.get(`https://api.terhambar.com/ninja?nama=${teks}`).then((res) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Info Ig Yang Anda cari🔎', MessageType.text)
    let hasil = `Nama Ninja kamu Adalah:\n\n${res.data.result.ninja}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text == '.help'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, xp.xp(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
if (text == '.menu1'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, xp1.xp1(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
if (text == '.menu2'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, xp2.xp2(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
if (text == '.menu3'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, xp3.xp3(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
if (text == '.menu4'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, xp4.xp4(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
if (text == '.menu5'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, xp5.xp5(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
if (text == '.menu6'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, xp6.xp6(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
if (text == '.menu7'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, xp7.xp7(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
if (text == '.menu8'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, xp8.xp8(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
else if (text == '.donate'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
if (text == '.menu9'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, xp9.xp9(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
else if (text == '.donate'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
else if (text == '.donasi'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, XPTN, corohelp, tampilTanggal, tampilWaktu, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
else if (text == '.DONATE'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, XPTN, corohelp, tampilTanggal, tampilWaktu, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
else if (text == '.DONASI'){
  const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, XPTN, corohelp, tampilTanggal, tampilWaktu, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
else if (text == '.info'){
  const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, info.info(id, XPTN, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwa, youtube) ,MessageType.text);
}
else if (text == '.foto'){
conn.sendMessage(id, 'kirim .foto cewek/cowok\n\nContoh: .foto cewek' ,MessageType.text);
}
else if (text == '.help'){
conn.sendMessage(id, ' _TERIMAKASIH BANYAK TELAH MENGGUNAKAN FITUR INI... JANGAN LUPA UNTUK DONASI YA' ,MessageType.text);
}
else if (text == '.menu1'){
conn.sendMessage(id, ' terimakasih sudah menggunakan bot Yanz Bot jangan lupa follow ig mimin ya @iyanmikasa' ,MessageType.text);
}
else if (text == '.menu'){
conn.sendMessage(id, ' terimakasih sudah menggunakan bot Yanz Bot jangan lupa follow ig mimin ya @iyanmikasa' ,MessageType.text);
}
else if (text == '.menu2'){
conn.sendMessage(id, 'terimakasih sudah menggunakan bot Yanz Bot jangan lupa follow ig mimin ya @iyanmikasa' ,MessageType.text);
}
else if (text == '.menu3'){
conn.sendMessage(id, ' terimakasih sudah menggunakan bot Yanz Bot jangan lupa follow ig mimin ya @iyanmikasa' ,MessageType.text);
}
else if (text == '.menu4'){
conn.sendMessage(id, ' terimakasih sudah menggunakan bot Yanz Bot jangan lupa follow ig mimin ya @iyanmikasa' ,MessageType.text);
}
else if (text == '.menu5'){
conn.sendMessage(id, ' terimakasih sudah menggunakan bot Yanz Bot jangan lupa follow ig mimin ya @iyanmikasa' ,MessageType.text);
}
else if (text == '.menu6'){
conn.sendMessage(id, ' terimakasih sudah menggunakan bot Yanz Bot jangan lupa follow ig mimin ya @iyanmikasa' ,MessageType.text);
}
else if (text == '.menu7'){
conn.sendMessage(id, ' terimakasih sudah menggunakan bot Yanz Bot jangan lupa follow ig mimin ya @iyanmikasa' ,MessageType.text);
}
   if (messageType == 'imageMessage')
   {
      let caption = imageMessage.caption.toLocaleLowerCase()
      const buffer = await conn.downloadMediaMessage(m) // to decrypt & use as a buffer
      if (caption == '.sticker')
      {
         const stiker = await conn.downloadAndSaveMediaMessage(m) // to decrypt & save to file

         const
         {
            exec
         } = require("child_process");
         exec('cwebp -q 50 ' + stiker + ' -o temp/' + jam + '.webp', (error, stdout, stderr) =>
         {
            let stik = fs.readFileSync('temp/' + jam + '.webp')
            conn.sendMessage(id, stik, MessageType.sticker)
         });
      }
   }

   if (messageType === MessageType.text)
   {
      let is = m.message.conversation.toLocaleLowerCase()

      if (is == '.pantun')
      {

         fetch('https://raw.githubusercontent.com/pajaar/grabbed-results/master/pajaar-2020-pantun-pakboy.txt')
            .then(res => res.text())
            .then(body =>
            {
               let tod = body.split("\n");
               let pjr = tod[Math.floor(Math.random() * tod.length)];
               let pantun = pjr.replace(/pjrx-line/g, "\n");
               conn.sendMessage(id, pantun, MessageType.text)
            });
      }
   }
   if (text.includes(".covid"))
   {
const get = require('got')
    const body = await get.post('https://api.kawalcorona.com/indonesia', {

    }).json();
    var positif = (body[0]['positif']);
    var sembuh  = (body[0]['sembuh']);
    var meninggal = (body[0]['meninggal']);
    var dirawat = (body[0]['dirawat']);
    console.log(body[0]['name'])
    conn.sendMessage(id,`🔎DATA WABAH COVID-19 TERBARU DI INDONESIA🔍\n\n📈Positif ==> ${positif} \n📉Sembuh ==> ${sembuh} \n📋Meninggal ==> ${meninggal}\n🗒️Dirawat ==> ${dirawat}`, MessageType.text);
}
   if (text.includes(".quotes"))
   {
      var url = 'https://jagokata.com/kata-bijak/acak.html'
      axios.get(url)
         .then((result) =>
         {
            let $ = cheerio.load(result.data);
            var author = $('a[class="auteurfbnaam"]').contents().first().text();
            var kata = $('q[class="fbquote"]').contents().first().text();

            conn.sendMessage(
               id,
               `
_${kata}_
        
    
	*~${author}*
         `, MessageType.text
            );

         });
   }
   
   if (text.includes(".hentai"))
   {
    var items = ["nsfwneko","anime hentai"];
    var anim = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.computerfreaker.cf/v1/";
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var anim =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(anim) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image)
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }


   
   if (text.includes(".loli"))
   {
    var items = ["anime loli","anime loli sange","anime loli fackgirll","anime loli i love you", "anime loli hd", "anime loli aesthetic"];
    var nime = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + nime;
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }
    
   if (text.includes(".shota"))
   {
    var items = ['shota anime', 'anime shota'];
    var nime = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + nime;

    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek = n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek)
        .then(
            (response) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }
    
if (text.includes(".pokemon"))
   {
    var items = ["anime pokemon", "anime pokemon hd", "anime pokemon lucu"];
    var nime = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + nime;
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
        conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }
   
else if (text.includes(".artinama")) 
  {
    const cheerio = require('cheerio');
    const request = require('request');
    var nama = text.split(".artinama ")[1];
    var req = nama.replace(/ /g,"+");
    request.get({
        headers: {'content-type' : 'application/x-www-form-urlencoded'},
        url:     'http://www.primbon.com/arti_nama.php?nama1='+ req +'&proses=+Submit%21+',
      },function(error, response, body){
          let $ = cheerio.load(body);
          var y = $.html().split('arti:')[1];
          var t = y.split('method="get">')[1];
          var f = y.replace(t ," ");
          var x = f.replace(/<br\s*[\/]?>/gi, "\n");
          var h  = x.replace(/<[^>]*>?/gm, '');
      console.log(""+ h);
      conn.sendMessage(id,
            `
      Arti dari nama ${nama} adalah

-----------------------------------

         Nama ${nama} ${h}
         
-----------------------------------

`,
 MessageType.text, { quoted: m });
  });
  }
  else if (text.includes(".pasangan ")) {
    const request = require('request');
    var gh = text.split(".pasangan ")[1];
    var namamu = gh.split("&")[0];
    var pasangan = gh.split("&")[1];
    request.get({
        headers: {'content-type' : 'application/x-www-form-urlencoded'},
        url:     'http://www.primbon.com/kecocokan_nama_pasangan.php?nama1='+ namamu +'&nama2='+ pasangan +'&proses=+Submit%21+',

    },function(error, response, body){
        let $ = cheerio.load(body);
      var y = $.html().split('<b>KECOCOKAN JODOH BERDASARKAN NAMA PASANGAN</b><br><br>')[1];
        var t = y.split('.<br><br>')[1];
        var f = y.replace(t ," ");
        var x = f.replace(/<br\s*[\/]?>/gi, "\n");
        var h  = x.replace(/<[^>]*>?/gm, '');
        var d = h.replace("&amp;", '&')
      console.log(""+ d);
      conn.sendMessage(id, `
---------------------
 *Kecocokan berdasarkan nama yang di cocokkan*
 ${d}
---------------------
    `, MessageType.text);
  });
  }
   if (text.includes(".foto cewek"))
   {
    var items = ["ullzang girl", "cewe cantik", "cewe imut", "korean girl", "remaja cantik", "cewek korea", "cewek jepang kawai", "cewe rusia imut"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }

   if (text.includes(".foto cowok"))
   {
    var items = ["cowo ganteng", "cogan", "korean boy", "chinese boy", "japan boy", "cowok indo ganteng", "cowok korea", "cowo rusia"];
    var cowo = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cowo;
    
    axios.get(url)
      .then((result) => {
        var z = JSON.parse(JSON.stringify(result.data));
        var cowok =  z[Math.floor(Math.random() * z.length)];
        imageToBase64(cowok) 
        .then(
            (response) => {
  conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
  var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }

if (text.includes(".wallpaperpc")) 
   {
    var items = ["wallpaper komputer", "wallpaper komputer anime", "wallpaper komputer gaming", "wallpaper komputer aesthetic", "wallpaper komputer hd"];
    var cewe = items[Math.floor(Math.random() * items.length)]; 
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe; 
    
    axios.get(url) 
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".wallpaperhp"))
   {
    var items = ["wallpaper android", "wallpaper android anime", "wallpaper android gaming", "wallpaper android aesthetic", "wallpaper android hd"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".husbu"))
   {
    var items = ["husbu", "husbu hd", "husbu ganteng", "husbu anime", "husbu aesthetic"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".yaoi"))
   {
    var items = ["anime yaoi", "anime yaoi hd", "anime yaoi aesthetic", "yaoi"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".doggy"))
   {
    var items = ["anjing lucu", "anjing imut", "anjing"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".haikyuu"))
   {
    var items = ["anime haikyuu", "anime haikyuu hd", "karakter anime haikyuu", "anime haikyuu aesthetic", "wallpaper komputer haikyuu", "wallpaper android haikyuu"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".yuri"))
   {
    var items = ["anime yuri", "anime yuri hd", "anime yuri aesthetic", "yuri"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".naruto"))
   {
    var items = ["anime naruto", "anime naruto hd", "anime naruto aesthetic", "wallpaper komputer naruto", "wallpaper android naruto", "naruto uzumaki hd", "karakter anime naruto"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".jujutsu"))
   {
    var items = ["anime jujutsu kaisen", "anime jujutsu kaisen hd", "karakter anime jujutsu kaisen", "wallpaper komputer jujutsu kaisen", "wallpaper android jujutsu kaisen"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".knn"))
   {
    var items = ["anime kimi no na wa", "anime kimi no na wa hd", "karakter anime kimi no na wa", "wallpaper komputer kimi no na wa", "wallpaper android kimi no na wa"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".wwy"))
   {
    var items = ["anime weathering with you", "anime weathering with you hd", "karakter anime weathering with you", "wallpaper komputer weathering with you", "wallpaper android weathering with you"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".aot"))
   {
    var items = ["anime attack on titan", "anime attack on titan hd", "anime attack on titan aesthetic", "karakter attack on titan", "wallpaper komputer attack on titan", "wallpaper android attack on titan"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".neko"))
   {
    var items = ["kucing", "kucing lucu", "kucing imut"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".zoo"))
   {
    var items = ["foto binatang hd", "foto binatang", "foto binatang aesthetic"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".force"))
   {
    var items = ["anime fire force hd", "anime fire force", "anime fire force aesthetic", "wallpaper komputer fire force", "wallpaper android fire force"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".ff"))
   {
    var items = ["game free fire", "wallpaper komputer game free fire", "wallpaper android game free fire", "free fire aesthetic", "free fire hd"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".ml"))
   {
    var items = ["game mobile legend", "wallpaper komputer game mobile legend", "wallpaper android game mobile legend", "mobile legend aesthetic", "mobile legend hd"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".fortnite"))
   {
    var items = ["game fortnite", "wallpaper komputer game fortnite", "wallpaper android game fortnite", "fornite aesthetic", "fornite hd"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".pubg"))
   {
    var items = ["game pubg", "wallpaper komputer game pubg", "wallpaper android game pubg", "pubg aesthetic", "pubg hd"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".dxd"))
   {
    var items = ["anime high school dxd", "anime high school dxd hd", "karakter anime high school dxd", "anime high school dxd aesthetic", "wallpaper komputer high school dxd", "wallpaper android high school dxd"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".ec"))
   {
    var items = ["anime elite classroom", "anime elite classroom", "karakter anime elite classroom", "anime elite classroom aesthetic", "wallpaper komputer elite classroom", "wallpaper android elite classroom"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".bc"))
   {
    var items = ["anime black clover", "anime black clover hd", "karakter anime black clover", "wallpaper komputer black clover", "wallpaper android black clover", "anime black clover aesthetic"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".cari"))
   {
    var url = "https://api.fdci.se/rep.php?gambar=" + teks;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".fotoanime"))
   {
    var items = ["anime girl", "anime cantik", "anime", "anime aesthetic", "anime hd", "anime kawai"];
    var nime = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + nime;
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
    conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }
 
if (text.includes(".lirik")){
	const teks = text.split(".lirik")[1]
	axios.get(`http://scrap.terhambar.com/lirik?word=${teks}`).then ((res) => {
	     conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	 	let hasil = `🎶lirik🎶 lagu ${teks} \n\n\n ${res.data.result.lirik}`
	conn.sendMessage(id, hasil, MessageType.text)
	})
}
if (text.includes(".bok"))
   {
    var items = ["cewe buka baju", "cewe telanjang", "cewe sangean", "cewe bokep"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image)
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes(".meme"))
   {
    var items = ["meme indonesia", "meme indonesia 2020", "meme lucu indonesia", "meme lucu bahasa indonesia"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, {caption: "🔍Foto Telah di temukan\n\nBerhasil💯", quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
      if (text.includes(".chord2")){
const teks = text.replace(/.chord3 /, "")
axios.get(`https://st4rz.herokuapp.com/api/chord?q=${teks}`).then((res) => {
    let hasil = `${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
  })
 }
else if (text == '.pesankosong'){
conn.sendMessage(id, '͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏' ,MessageType.text);
}
  if (text.includes(".hostsearch")){
const teks = text.replace(/.hostsearch /, "")
axios.get(`https://api.banghasan.com/domain/hostsearch/${teks}`).then((res) => {
    let hasil = `*query : ${res.data.query}*\n\nhasil : ${res.data.hasil}`;
    conn.sendMessage(id, hasil ,MessageType.text);
  })
 }
if (text.includes(".jadwaltvnow")){
const teks = text.replace(/.jadwalTV /, "")
axios.get(`https://api.haipbis.xyz/jadwaltvnow`).then((res) => {
    let hasil = `Jam : ${res.data.jam}\n\n${res.data.jadwalTV}`;
    conn.sendMessage(id, hasil ,MessageType.text);
  })
 }
if (text.includes(".ytmp4"))
   {
      const url = text.replace(/.ytmp4 /, "");
      const exec = require('child_process').exec;

      var videoid = url.match(/(?:https?:\/{2})?(?:w{3}\.)?youtu(?:be)?\.(?:com|be)(?:\/watch\?v=|\/)([^\s&]+)/);

      const ytdl = require("ytdl-core")
      if (videoid != null)
      {
         console.log("video id = ", videoid[1]);
      }
      else
      {
         conn.sendMessage(id, "maaf, link yang anda kirim tidak valid", MessageType.text)
      }
      ytdl.getInfo(videoid[1]).then(info =>
      {
         if (info.length_seconds > 1000)
         {
            conn.sendMessage(id, " videonya kepanjangan", MessageType.text)
         }
         else
         {

            console.log(info.length_seconds)

            function os_func()
            {
               this.execCommand = function (cmd)
               {
                  return new Promise((resolve, reject) =>
                  {
                     exec(cmd, (error, stdout, stderr) =>
                     {
                        if (error)
                        {
                           reject(error);
                           return;
                        }
                        resolve(stdout)
                     });
                  })
               }
            }
            var os = new os_func();

            os.execCommand('ytdl ' + url + ' -q highest -o mp4/' + videoid[1] + '.mp4').then(res =>
            {
		const buffer = fs.readFileSync("mp4/"+ videoid[1] +".mp4")
               conn.sendMessage(id, buffer, MessageType.video)
            }).catch(err =>
            {
               console.log("os >>>", err);
            })

         }
      });

   }






   
         
  


if (text.includes('.profileig')){
  var teks = text.replace(/%profileig /, '')
    axios.get('https://arugaz.herokuapp.com/api/stalk?username='+teks)
    .then((res) => {
      imageToBase64(res.data.Profile_pic)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}
if (text.includes('.ssweb')){
  var teks = text.replace(/.ssweb /, '')
    axios.get('https://api.haipbis.xyz/ssweb?url='+teks)
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[❗] SEDANG DIPROSES', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}
if (text == ".waifu") {
var url = 'https://st4rz.herokuapp.com/api/waifu'
   axios.get(url)
  .then(res => {
      	const { image, name, desc } = res.data
      
      const hasil = `Name : ${res.data.name}\n\nDeskripsi : ${res.data.desc}`

    imageToBase64(res.data.image)

    .then(

            (response) => {
conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)

  var buf = Buffer.from(response, 'base64'); 

              conn.sendMessage(

            id,

              buf,MessageType.image, { caption: hasil, quoted: m })

       }

        )

        .catch(

            (error) => {

                console.log(error);

            })
            })

            }
if (text.includes(".ytmp3")) {
const teks = text.replace(/.ytmp3 /, "")
		var url = 'https://st4rz.herokuapp.com/api/yta2?url=' + teks
        axios.get(url)
            .then(res => {
            	conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
 imageToBase64(res.data.thumb)
                .then(
            (response) => {
            	
	var buf = Buffer.from(response, 'base64'); 
const { BitlyClient } = require('bitly');
const bitly = new BitlyClient('5ed1151721e9e8b878940031822091b078b406cd', {});
bitly
  .shorten(res.data.result)
  .then(function(result) {
    console.log(result);
    conn.sendMessage(id , buf, MessageType.image, { caption: `Judul : ${res.data.title}\nLink : ${result.link}`, quoted: m })
  })
  .catch(function(error) {
    console.error(error);
  });
  })
	})
	}
if (text.includes(".nekopoi")){
const teks = text.replace(/.nekopoi /, "") 
axios.get(`https://mhankbarbar.herokuapp.com/api/nekopoi?url=${teks}&apiKey=N2Ws9kp3KTDYtry5Jjyz`).then((res) =>{ 
    let hasil = `➸ *nekopoi link tersedia* : ${res.data.judul}\n*result* : ${res.data.result}\n*dilihat* : ${res.data.dilihat}\n*tumbnail* : ${res.data.tumbnail}` 
    conn.sendMessage(id, hasil, MessageType.text); 
})
}
if (text.includes('.memecreate')){
  var teks = text.replace(/.memecreate /, '')
    axios.get(`https://mnazria.herokuapp.com/api/create-meme?text-atas=${teks}`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}
if (text.includes(".ping2")){
const teks = text.replace(/.ping2 /, "")
axios.get(`https://api.banghasan.com/domain/nping/${teks}`).then((res) => {
    let hasil = `*query : ${res.data.query}*\n\nhasil : ${res.data.hasil}`;
    conn.sendMessage(id, hasil ,MessageType.text);
  })
 }
if (text.includes('.waifu2')){
  var teks = text.replace(/.waifu2 /, '')
    axios.get('https://st4rz.herokuapp.com/api/waifu')
    .then((res) => {
      imageToBase64(res.data.image)
        .then(
          (ress) => {
            conn.sendMessage(id, '[WAIT]Sedang Mencari Foto Yang Anda cari🔎', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
              conn.sendMessage(id , buf , MessageType.image, { caption: `🔍Foto Telah di temukan\n\nBerhasil💯`, quoted: m })
        })
    })
}
if (text.includes('.ttp')){
  var teks = text.replace(/.ttp /, '')
    axios.get(`https://mhankbarbars.herokuapp.com/api/text2image?text=${teks}&apiKey=N2Ws9kp3KTDYtry5Jjyz`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}
else if (text == '.hello1'){
let hasil = fs.readFileSync('mp3/' + 'PTT' + '.wav')
 conn.sendMessage(id, hasil, MessageType.audio, { quoted: m } )
}
if (text.includes("test")){
let err = fs.readFileSync('mp3/' + 'test' + '.mav')
 conn.sendMessage(id, err, MessageType.audio, { quoted: m })
}
if (text.includes("salam")){
let err = fs.readFileSync('mp3/' + 'salam' + '.mp3')
 conn.sendMessage(id, err, MessageType.audio, { ptt: true })
}
if (text.includes("tariksis")){
let err = fs.readFileSync('mp3/' + 'tariksis' + '.wav')
 conn.sendMessage(id, err, MessageType.audio, { ptt: true, quoted: m })
}
if (text.includes('bot')) {
 var nomor = m.participant
 const options = {
       text: `ada apa sayang manggil manggil ketik .help @${nomor.split("@s.whatsapp.net")[0]}, untuk menampilkan fitur fitur bot ya`,
       contextInfo: { mentionedJid: [nomor] }
 }
 conn.sendMessage(id, options, MessageType.text, { quoted: m })
}
if (text.includes(".Desah")){
let err = fs.readFileSync('mp3/' + 'desah' + '.mp3')
 conn.sendMessage(id, err, MessageType.audio, { ptt: true, quoted: m })
}
if (text.includes(".desah")){
let err = fs.readFileSync('mp3/' + 'desah' + '.mp3')
 conn.sendMessage(id, err, MessageType.audio, { ptt: true, quoted: m })
}
if (text.includes(".iri")){
let err = fs.readFileSync('mp3/' + 'iri' + '.mp3')
 conn.sendMessage(id, err, MessageType.audio, { ptt: true, quoted: m })
}
else if (text == '.baka'){
let hasil = fs.readFileSync('mp3/' + 'baka' + '.mp3')
 conn.sendMessage(id, hasil, MessageType.audio, { quoted: m } )
}
else if (text == '.welot'){
let hasil = fs.readFileSync('mp3/' + 'welot' + '.mp3')
 conn.sendMessage(id, hasil, MessageType.audio, { ptt: true, quoted: m })
}
else if (text == '.tarekses'){
let hasil = fs.readFileSync('mp3/' + 'tarekses' + '.mp3')
 conn.sendMessage(id, hasil, MessageType.audio, { ptt: true, quoted: m })
}
else if (text == '.abngjgo'){
let hasil = fs.readFileSync('mp3/' + 'bgjg' + '.mp3')
 conn.sendMessage(id, hasil, MessageType.audio, { ptt: true, quoted: m })
}
else if (text == '.roti'){
let hasil = fs.readFileSync('mp3/' + 'roti' + '.wav')
 conn.sendMessage(id, hasil, MessageType.audio, { quoted: m } )
}
else if (text == '.salam'){
let hasil = fs.readFileSync('mp3/' + 'salam' + '.mp3')
 conn.sendMessage(id, hasil, MessageType.audio, { quoted: m } )
}
else if (text == '.goblok'){
let hasil = fs.readFileSync('mp3/' + 'goblok' + '.wav')
 conn.sendMessage(id, hasil, MessageType.audio, { quoted: m } )
}
else if (text == '.Goblok'){
let hasil = fs.readFileSync('mp3/' + 'goblok' + '.wav')
 conn.sendMessage(id, hasil, MessageType.audio, { quoted: m } )
}
else if (text == '.pota'){
let hasil = fs.readFileSync('mp3/' + 'tes2' + '.mp3')
 conn.sendMessage(id, hasil, MessageType.audio, { ptt: true, quoted: m })
}
else if (text == '.Pota'){
let hasil = fs.readFileSync('mp3/' + 'tes2' + '.mp3')
 conn.sendMessage(id, hasil, MessageType.audio, { ptt: true, quoted: m })
}
else if (text == '.tariksis'){
let hasil = fs.readFileSync('mp3/' + 'tariksis' + '.mp3')
 conn.sendMessage(id, hasil, MessageType.audio, { ptt: true, quoted: m })
}
else if (text == '.Tariksis'){
let hasil = fs.readFileSync('mp3/' + 'tariksis' + '.mp3')
 conn.sendMessage(id, hasil, MessageType.audio, { ptt: true, quoted: m })
}
else if (text == '.Iri'){
let hasil = fs.readFileSync('mp3/' + 'iri' + '.mp3')
 conn.sendMessage(id, hasil, MessageType.audio, { ptt: true, quoted: m })
}
else if (text == '.song1'){
let hasil = fs.readFileSync('mp3/' + 'yan' + '.mp3')
 conn.sendMessage(id, hasil, MessageType.audio, { ptt: true, quoted: m })
}
if (text.includes(".alay")){
const alay = text.split(".alay")[1]
axios.get(`https://api.terhambar.com/bpk?kata=${alay}`).then ((res) =>
    { let hasil = `${res.data.text}`
    conn.sendMessage(id, hasil, MessageType.text)
  })
 }

//Tolonglah bro jangan di ubah ubah 


})
