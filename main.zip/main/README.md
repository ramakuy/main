### YanzBot




### Alat dan Bahan
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan kode qr kak)
> jaringan internet kenceng,kuota+
> penyimpanan yang memadai
> aplikasi whatsapp
> aplikasi termux
> kopi+rokok ;v
```

### Informasi Pengguna
Script ini di modifikasi sama saya sendiri Yanz
```bash
> Support My Github😘
> Jangan Lupa follow github saya🤗
> jika error lapor ke Pembuat script chat wa link ada di github 
```
### Cara Installnya
Script ini di modifikasi sama saya sendiri Yanz.
```bash
kalo lu belum punya apk termux, download di playstore
> masuk ke apk termux lalu ketik dibawah ini!
> termux-setup-storage
> pkg install git && pkg install tesseract && pkg install wget && pkg install ffmpeg && pkg install nodejs
> apt update && apt upgrade
> git clone ******
> cd XP-TNNBOT
> npm i -g cwebp && npm i node-tesseract-ocr && npm i -g ytdl && npm i  && npm i got && npm i bitly && npm i performance-now && npm i imgbb-uploader && npm i @adiwajshing/baileys && npm i cfont && npm i spinnies && node index js
> Tinggal scan kode qr yeee...done
```
### install bahan² untuk PC/RDP
Siapin alat dan bahannya.
```bash
> Download Nodejs
> jika udah open laLU install script ini
> jika udh semua kalian pindahkan ke localdisk c
> jika udah ketik di nodejs nya cd *****
> npm i ytdl
> npm i cwebp
> npm i
> npm i got
> node index.js
```
### masih sebagaiyan vitur masih ada bug
```php
Nanti kami betulkan😘 jnagan lupa follow
Github ini dan support😅
```
## Features

| XP-TNBOT      |                   Feature        |
 :-----------: | :------------------------------: |
|       ✅       | Sticker Creator                  |
|       ✅       | Nulis                            |
|       ✅       | Covid (new)                      |
|       ✅       | Alay (new)                       |
|       ✅       | Lirik (new)                      |
|       ✅       | Foto Anime                       |
|       ✅       | Foto cewek/cowok (new)           |
|       ✅       | Pantun                           |
|       ✅       | Youtube Downloader               |
|       ✅       | Quotes                           |
|       ✅       | Nama (new)                       |
|       ✅       | Foto Anime                       |
|       ✅       | Pasangan (new)                   |
|       ✅       | Sholat (new )                    |
|       ✅       | Suara Google (fix)               |
|       ✅       | Quran                            |
|       ✅       | Youtube MP3 Downloader           |
|       ✅       | Intagram Downloader              |
|       ✅       | Twitter Downloader               |
|       ✅       | Facebook Downloader              |
|       ✅       | TikTok Downloader  (new)         |
|       ✅       | Wikipedia                        |
|       ✅       | Say                              |
|       ✅       | Toxic (new)                      |
|       ✅       | loli                             |
|       ✅       | hentai                           |
|       ✅       | anime (new)                      |
|       ✅       | Owner (new)                      |
|       ✅       | kata bijak                       |
|       ✅       | Fakta                            |
|       ✅       | Pokemon                          |
|       ✅       | Info                             |
|       ✅       | Donate                           |
|                   MORE                           |

## Note
BOT INI KHUSUS HP/TERMUX DOANG YAH,JIKA MAU RE-UPLOAD CANTUMKAN NAMA SAYA (XP-TN)

## Sosial Media Admin
* [`Youtube Admin`](https://www.youtube.com/channel/UCMiQsqzWvj-zKxNlFlG_Wiw)
* [`Instagram Admin`](https://instagram.com/mragung23)
* [`WhatsApp Admin `](https://wa.me/+6289655478810)

##THANKS TO MY FRENDS
* [`caliph71 Github`](https://github.com/Caliph71)
<p align="center">
<a href="https://www.appcreator24.com/app1317131"</a>
</p>
